import React, { useState } from 'react';
import { Portal3DCanvas } from './Portal3DCanvas';
import { Shield, Sparkles, ArrowRight, Lock } from 'lucide-react';

interface LandingPageProps {
  onEnterStudentPortal: () => void;
  onEnterAdmin: () => void;
  onEnterSafeguarding: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onEnterStudentPortal,
  onEnterAdmin,
  onEnterSafeguarding
}) => {
  const [isWarping, setIsWarping] = useState(false);

  const handleEnter = () => {
    setIsWarping(true);
    // Smooth warp transition
    setTimeout(() => {
      onEnterStudentPortal();
    }, 700);
  };

  return (
    <div className="relative min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between items-center overflow-hidden select-none">
      {/* 3D WebGL Digital Portal Canvas Background */}
      <Portal3DCanvas isWarping={isWarping} />

      {/* Atmospheric Aurora Digital Gradient Overlays */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-[#080B20]/80 via-transparent to-[#080B20]/90 z-10" />

      {/* Top Header Zone: Clean School Identity */}
      <header className="relative z-20 w-full max-w-6xl mx-auto px-6 py-6 flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-3">
          {/* Emblem Glowing Portal Logo */}
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#36CFFF] to-[#876BFF] p-0.5 shadow-[0_0_15px_rgba(54,207,255,0.4)]">
            <div className="w-full h-full bg-[#080B20] rounded-[10px] flex items-center justify-center">
              <div className="w-4 h-4 rounded-full border-2 border-[#36CFFF] border-t-transparent animate-spin" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-xs uppercase tracking-[0.25em] text-[#36CFFF] font-semibold">
              SMP NEGERI 1 UNGARAN
            </span>
            <span className="text-[11px] text-[#D5E9FF]/60 tracking-wider">
              Kabupaten Semarang · Jawa Tengah
            </span>
          </div>
        </div>
      </header>

      {/* Center Cinematic Content */}
      <main className="relative z-20 flex flex-col items-center justify-center text-center px-4 max-w-3xl mx-auto my-auto pointer-events-auto">
        {/* Subtle school kicker */}
        <div className="mb-4 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#142B54]/50 border border-[#36CFFF]/30 backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-[#36CFFF]" />
          <span className="text-xs font-medium tracking-wide text-[#D5E9FF]">
            Platform Resmi Aspirasi Siswa
          </span>
        </div>

        {/* Futuristic Main Title */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight font-display mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white via-[#D5E9FF] to-[#876BFF] drop-shadow-[0_0_35px_rgba(54,207,255,0.35)]">
          PORTAL ASPIRASI SISWA
        </h1>

        {/* Motto: Suaramu, Perubahan Kita. */}
        <p className="text-lg sm:text-xl md:text-2xl font-light text-[#D5E9FF]/90 mb-10 tracking-wide font-sans">
          &ldquo;Suaramu, Perubahan Kita.&rdquo;
        </p>

        {/* Neon Glass Button: MASUK KE RUANG ASPIRASI ↗ */}
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <button
            onClick={handleEnter}
            disabled={isWarping}
            className={`glass-button-neon group relative px-8 py-4 rounded-2xl text-base sm:text-lg font-bold tracking-wider text-white flex items-center gap-3 cursor-pointer ${
              isWarping ? 'scale-95 opacity-80' : ''
            }`}
          >
            <span className="tracking-widest">MASUK KE RUANG ASPIRASI</span>
            <span className="text-[#36CFFF] group-hover:translate-x-1 group-hover:-translate-y-0.5 transition-transform duration-200">
              ↗
            </span>
          </button>
        </div>

        <p className="mt-6 text-xs text-[#D5E9FF]/50 max-w-md mx-auto">
          Sampaikan pendapat, usulan fasilitas, kegiatan OSIS, atau laporkan kendala sekolah dengan aman & transparan.
        </p>
      </main>

      {/* Bottom Footer & Discreet Staff/Admin Access */}
      <footer className="relative z-20 w-full max-w-6xl mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 pointer-events-auto border-t border-white/5">
        <p className="text-xs text-[#D5E9FF]/40">
          © 2026 SMP Negeri 1 Ungaran · Student Aspirations Portal
        </p>

        <div className="flex items-center gap-4">
          <button
            onClick={onEnterSafeguarding}
            className="flex items-center gap-1.5 text-xs text-[#D5E9FF]/50 hover:text-[#36CFFF] transition-colors cursor-pointer"
            title="Kanal Khusus Guru BK & Petugas Penanganan Perundungan"
          >
            <Shield className="w-3.5 h-3.5 text-[#876BFF]" />
            <span>Kanal Khusus Guru BK</span>
          </button>

          <span className="text-[#D5E9FF]/20">·</span>

          <button
            onClick={onEnterAdmin}
            className="flex items-center gap-1.5 text-xs text-[#D5E9FF]/50 hover:text-white transition-colors cursor-pointer"
            title="Akses Pengurus OSIS & Administrator"
          >
            <Lock className="w-3.5 h-3.5 text-[#36CFFF]" />
            <span>Login Admin OSIS</span>
          </button>
        </div>
      </footer>
    </div>
  );
};
