import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface Portal3DCanvasProps {
  onIntroComplete?: () => void;
  isWarping?: boolean;
}

export const Portal3DCanvas: React.FC<Portal3DCanvasProps> = ({
  onIntroComplete,
  isWarping = false
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [introElapsed, setIntroElapsed] = useState(0);
  const [isSkipped, setIsSkipped] = useState(false);
  const animFrameIdRef = useRef<number | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Check prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x080b20, 0.045);

    const camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0, 16);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    container.appendChild(renderer.domElement);

    // Group for the 3D Portal Gate
    const portalGroup = new THREE.Group();
    scene.add(portalGroup);

    // Colors
    const cyanColor = new THREE.Color('#36CFFF');
    const violetColor = new THREE.Color('#876BFF');
    const iceColor = new THREE.Color('#D5E9FF');

    // 1. Concentric Glowing Portal Rings
    const ringMaterials: THREE.MeshBasicMaterial[] = [];
    const ringMeshes: THREE.Mesh[] = [];

    const ringRadii = [4.5, 3.8, 3.0, 2.2];
    ringRadii.forEach((radius, idx) => {
      const tube = idx % 2 === 0 ? 0.08 : 0.04;
      const ringGeom = new THREE.TorusGeometry(radius, tube, 16, 100);
      const color = idx % 2 === 0 ? cyanColor : violetColor;
      const mat = new THREE.MeshBasicMaterial({
        color: color,
        transparent: true,
        opacity: 0.85,
        wireframe: idx === 1
      });
      ringMaterials.push(mat);
      const mesh = new THREE.Mesh(ringGeom, mat);
      portalGroup.add(mesh);
      ringMeshes.push(mesh);
    });

    // 2. Segmented Runes / Glyphs Ring
    const segments = 24;
    const glyphGroup = new THREE.Group();
    for (let i = 0; i < segments; i++) {
      const angle = (i / segments) * Math.PI * 2;
      const r = 5.2;
      const geom = new THREE.BoxGeometry(0.2, 0.5, 0.05);
      const mat = new THREE.MeshBasicMaterial({
        color: i % 3 === 0 ? cyanColor : iceColor,
        transparent: true,
        opacity: 0.7
      });
      const box = new THREE.Mesh(geom, mat);
      box.position.set(Math.cos(angle) * r, Math.sin(angle) * r, 0);
      box.rotation.z = angle + Math.PI / 2;
      glyphGroup.add(box);
    }
    portalGroup.add(glyphGroup);

    // 3. Central Vortex Particles
    const particleCount = prefersReducedMotion ? 250 : 1200;
    const particleGeom = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);
    const particleSpeeds = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      // Cylinder/tunnel distribution
      const theta = Math.random() * Math.PI * 2;
      const rad = 0.5 + Math.random() * 4.5;
      const z = (Math.random() - 0.5) * 30;

      particlePositions[i * 3] = Math.cos(theta) * rad;
      particlePositions[i * 3 + 1] = Math.sin(theta) * rad;
      particlePositions[i * 3 + 2] = z;

      // Color interpolation cyan -> violet -> ice
      const col = Math.random() > 0.5 ? cyanColor : (Math.random() > 0.3 ? violetColor : iceColor);
      particleColors[i * 3] = col.r;
      particleColors[i * 3 + 1] = col.g;
      particleColors[i * 3 + 2] = col.b;

      particleSpeeds[i] = 0.05 + Math.random() * 0.15;
    }

    particleGeom.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeom.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.12,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending
    });
    const particleSystem = new THREE.Points(particleGeom, particleMat);
    scene.add(particleSystem);

    // Ambient and Point lights
    const ambientLight = new THREE.AmbientLight(0x080b20, 1.5);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x36cfff, 3, 30);
    pointLight.position.set(0, 0, 2);
    scene.add(pointLight);

    // Mouse parallax tracking
    let targetMouseX = 0;
    let targetMouseY = 0;
    let currentMouseX = 0;
    let currentMouseY = 0;

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      let clientX = 0;
      let clientY = 0;
      if ('touches' in e) {
        if (e.touches.length > 0) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
        }
      } else {
        clientX = e.clientX;
        clientY = e.clientY;
      }
      targetMouseX = (clientX / window.innerWidth) * 2 - 1;
      targetMouseY = -(clientY / window.innerHeight) * 2 + 1;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });

    // Handle Window Resize
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Cinematic Intro Timeline
    const startTime = performance.now();
    let introFinished = false;

    // Animation Loop
    let clock = new THREE.Clock();

    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);

      const delta = clock.getDelta();
      const totalElapsed = (performance.now() - startTime) / 1000;
      setIntroElapsed(Math.min(totalElapsed, 6.0));

      // Ease mouse parallax
      currentMouseX += (targetMouseX - currentMouseX) * 0.05;
      currentMouseY += (targetMouseY - currentMouseY) * 0.05;

      // Rotate rings at varying speeds
      ringMeshes.forEach((mesh, idx) => {
        const dir = idx % 2 === 0 ? 1 : -1;
        mesh.rotation.z += (0.4 + idx * 0.2) * dir * delta;
        mesh.rotation.x = Math.sin(totalElapsed * 0.5 + idx) * 0.12;
        mesh.rotation.y = Math.cos(totalElapsed * 0.5 + idx) * 0.12;
      });

      glyphGroup.rotation.z -= 0.2 * delta;

      // Animate Particles along Z toward camera
      const positions = particleGeom.attributes.position.array as Float32Array;
      const speedMultiplier = isWarping ? 8.0 : 1.0;

      for (let i = 0; i < particleCount; i++) {
        positions[i * 3 + 2] += particleSpeeds[i] * speedMultiplier;
        // Vortex swirl
        const x = positions[i * 3];
        const y = positions[i * 3 + 1];
        const angle = 0.01;
        positions[i * 3] = x * Math.cos(angle) - y * Math.sin(angle);
        positions[i * 3 + 1] = x * Math.sin(angle) + y * Math.cos(angle);

        // Reset if passed behind camera
        if (positions[i * 3 + 2] > 18) {
          positions[i * 3 + 2] = -12;
        }
      }
      particleGeom.attributes.position.needsUpdate = true;

      // Camera Animation (Cinematic 6s Opening or Ambient Mode)
      if (!isSkipped && totalElapsed < 6.0 && !prefersReducedMotion) {
        // 0s -> 2s: Portal grows from 0 to 1
        // 2s -> 4s: High rotation & glowing
        // 4s -> 6s: Camera moves closer and passes portal threshold
        if (totalElapsed < 2.0) {
          const t = totalElapsed / 2.0;
          portalGroup.scale.setScalar(THREE.MathUtils.lerp(0.1, 1.0, t));
          camera.position.z = 16;
        } else if (totalElapsed < 4.0) {
          portalGroup.scale.setScalar(1.0 + Math.sin((totalElapsed - 2) * Math.PI) * 0.05);
          camera.position.z = 16;
        } else {
          // Camera glides forward through portal
          const t = (totalElapsed - 4.0) / 2.0;
          const smoothT = t * t * (3 - 2 * t);
          camera.position.z = THREE.MathUtils.lerp(16, 2.5, smoothT);
        }
      } else {
        if (!introFinished) {
          introFinished = true;
          portalGroup.scale.setScalar(1.0);
          if (onIntroComplete && !isSkipped) {
            onIntroComplete();
          }
        }

        // Camera warp transition if warping to dashboard
        if (isWarping) {
          camera.position.z -= 0.6;
          portalGroup.scale.multiplyScalar(1.02);
          pointLight.intensity += 0.2;
        } else {
          // Ambient hovering camera
          camera.position.z = 14 + Math.sin(totalElapsed * 0.8) * 0.4;
          camera.position.x = currentMouseX * 1.5;
          camera.position.y = currentMouseY * 1.2;
          camera.lookAt(0, 0, 0);
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('resize', handleResize);
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      renderer.dispose();
      particleGeom.dispose();
      particleMat.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [isSkipped, isWarping, onIntroComplete]);

  const handleSkip = () => {
    setIsSkipped(true);
    if (onIntroComplete) {
      onIntroComplete();
    }
  };

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-auto">
      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Skip Intro Button (Top Right) per Section 2.2 */}
      {!isSkipped && introElapsed < 6.0 && (
        <div className="absolute top-6 right-6 z-30">
          <button
            onClick={handleSkip}
            className="group flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-[#D5E9FF]/70 hover:text-white bg-[#080B20]/60 hover:bg-[#142B54]/80 backdrop-blur-md border border-[#36CFFF]/30 hover:border-[#36CFFF]/70 rounded-full transition-all duration-200 cursor-pointer shadow-lg"
            aria-label="Lewati animasi pembuka"
          >
            <span>Lewati Intro</span>
            <span className="text-[10px] text-[#36CFFF] font-mono tabular-nums">
              ({Math.ceil(6 - introElapsed)}s)
            </span>
            <span className="text-[#36CFFF] group-hover:translate-x-0.5 transition-transform">→</span>
          </button>
        </div>
      )}
    </div>
  );
};
