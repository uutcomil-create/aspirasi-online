import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Aspiration, AspirationCategory, AspirationStatus, CATEGORIES } from '../types';
import { StorageService } from '../services/storage';
import { formatWIBDateTime, formatWIBDateOnly } from '../utils/date';
import { ClockWIB } from './ClockWIB';
import { CommentModal } from './CommentModal';
import {
  ArrowLeft,
  Search,
  Clock,
  CheckCircle,
  RefreshCw,
  Heart,
  MessageSquare,
  Share2,
  X,
  AlertCircle,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface AspirationListViewProps {
  onBackToDashboard: () => void;
  deviceId: string;
}

export const AspirationListView: React.FC<AspirationListViewProps> = ({
  onBackToDashboard,
  deviceId
}) => {
  const [aspirations, setAspirations] = useState<Aspiration[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');

  // Pagination (6 initial, +6 per load)
  const [visibleCount, setVisibleCount] = useState(6);

  // Selected for Detailed Holographic Modal
  const [activeAspiration, setActiveAspiration] = useState<Aspiration | null>(null);

  // Comment Modal state
  const [commentTargetAspiration, setCommentTargetAspiration] = useState<Aspiration | null>(null);

  // Preserved scroll position ref
  const scrollPositionRef = useRef<number>(0);

  const fetchAspirations = () => {
    try {
      setIsLoading(true);
      setLoadError(false);
      const list = StorageService.getPublishedAspirations();
      // Sort newest published first
      list.sort((a: Aspiration, b: Aspiration) => {
        const timeA = new Date(a.publishedAt || a.createdAt).getTime();
        const timeB = new Date(b.publishedAt || b.createdAt).getTime();
        return timeB - timeA;
      });
      setAspirations(list);
    } catch {
      setLoadError(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAspirations();
  }, []);

  // Filter & Search logic
  const filteredAspirations = useMemo(() => {
    return aspirations.filter((asp) => {
      const matchCategory = selectedCategory === 'Semua' || asp.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchQuery = !q || asp.title.toLowerCase().includes(q) || asp.content.toLowerCase().includes(q);
      return matchCategory && matchQuery;
    });
  }, [aspirations, selectedCategory, searchQuery]);

  const displayedAspirations = filteredAspirations.slice(0, visibleCount);

  // Like action (1 like per device, cannot unlike)
  const handleLike = (e: React.MouseEvent, aspirationId: string) => {
    e.stopPropagation();
    const success = StorageService.likeAspiration(aspirationId, deviceId);
    if (success) {
      // Update local state
      setAspirations((prev) =>
        prev.map((a) => (a.id === aspirationId ? { ...a, likesCount: a.likesCount + 1 } : a))
      );
      if (activeAspiration && activeAspiration.id === aspirationId) {
        setActiveAspiration((prev) => (prev ? { ...prev, likesCount: prev.likesCount + 1 } : null));
      }
    }
  };

  // WhatsApp Share per Section 8 (avoid window.open for iframe constraints)
  const handleShareWhatsApp = (asp: Aspiration) => {
    const summary = asp.content.length > 120 ? asp.content.substring(0, 120) + '...' : asp.content;
    const portalUrl = window.location.origin;
    const text = encodeURIComponent(
      `*Aspirasi Siswa SMP Negeri 1 Ungaran*\n\n` +
      `📌 *Kategori:* ${asp.category}\n` +
      `💡 *Judul:* ${asp.title}\n` +
      `📝 *Ringkasan:* ${summary}\n` +
      `⚡ *Status:* ${asp.status}\n\n` +
      `Pantau aspirasi dan pengumuman sekolah di Portal Aspirasi Spensa Ungaran:\n${portalUrl}`
    );
    const link = document.createElement('a');
    link.href = `https://api.whatsapp.com/send?text=${text}`;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Open Detailed Modal while preserving scroll
  const handleOpenDetail = (asp: Aspiration) => {
    scrollPositionRef.current = window.scrollY;
    setActiveAspiration(asp);
  };

  const handleCloseDetail = () => {
    setActiveAspiration(null);
    setTimeout(() => {
      window.scrollTo({ top: scrollPositionRef.current, behavior: 'instant' });
    }, 10);
  };

  // Close modal via Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (commentTargetAspiration) {
          setCommentTargetAspiration(null);
        } else if (activeAspiration) {
          handleCloseDetail();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeAspiration, commentTargetAspiration]);

  // Visual status helper per Section 7
  const renderStatusBadge = (status: AspirationStatus) => {
    switch (status) {
      case 'Menunggu Ditinjau':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Menunggu Ditinjau</span>
          </span>
        );
      case 'Sedang Ditinjau':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-cyan-300 bg-[#36CFFF]/10 px-2.5 py-1 rounded-lg border border-[#36CFFF]/25">
            <Search className="w-3.5 h-3.5 text-[#36CFFF]" />
            <span>Sedang Ditinjau</span>
          </span>
        );
      case 'Sedang Ditindaklanjuti':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-[#876BFF] bg-[#876BFF]/10 px-2.5 py-1 rounded-lg border border-[#876BFF]/25">
            <RefreshCw className="w-3.5 h-3.5 text-[#876BFF] animate-spin" style={{ animationDuration: '4s' }} />
            <span>Sedang Ditindaklanjuti</span>
          </span>
        );
      case 'Selesai':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-emerald-300 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/25">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Selesai</span>
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between aurora-bg animate-fadeIn">
      {/* Top Navbar */}
      <header className="w-full border-b border-[#36CFFF]/15 bg-[#080B20]/80 backdrop-blur-xl sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToDashboard}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#142B54]/60 hover:bg-[#142B54] border border-[#36CFFF]/30 text-xs text-[#D5E9FF] hover:text-white transition-all cursor-pointer group shadow-sm"
            >
              <ArrowLeft className="w-4 h-4 text-[#36CFFF] group-hover:-translate-x-0.5 transition-transform" />
              <span className="font-medium">Kembali ke Dashboard</span>
            </button>
            <div className="h-4 w-px bg-white/10" />
            <span className="text-xs font-bold text-white tracking-wider uppercase font-display">
              Daftar Aspirasi Siswa
            </span>
          </div>

          <ClockWIB />
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 flex-1">
        {/* Title & Description */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-4xl font-black font-display text-white mb-2 tracking-tight">
            Aspirasi Siswa SMP Negeri 1 Ungaran
          </h1>
          <p className="text-sm text-[#D5E9FF]/70 max-w-2xl">
            Kumpulan aspirasi umum yang telah ditinjau dan diterbitkan oleh Admin OSIS. Identitas pengirim dirahasiakan untuk menjaga kenyamanan seluruh siswa.
          </p>
        </div>

        {/* Search Bar & Category Filters */}
        <div className="space-y-4 mb-8">
          {/* Direct Search Input */}
          <div className="relative w-full">
            <Search className="w-5 h-5 text-[#36CFFF] absolute left-4 top-3.5 opacity-70" />
            <input
              type="text"
              placeholder="Cari aspirasi berdasarkan kata kunci judul atau isi uraian..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setVisibleCount(6);
              }}
              className="w-full bg-[#142B54]/50 border border-[#36CFFF]/25 rounded-2xl pl-12 pr-4 py-3 text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#36CFFF] focus:ring-1 focus:ring-[#36CFFF] backdrop-blur-md"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-3.5 text-xs text-[#D5E9FF]/50 hover:text-white cursor-pointer"
              >
                Reset
              </button>
            )}
          </div>

          {/* Category Filter Buttons */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none text-xs">
            <button
              onClick={() => {
                setSelectedCategory('Semua');
                setVisibleCount(6);
              }}
              className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer font-medium ${
                selectedCategory === 'Semua'
                  ? 'bg-[#36CFFF] text-[#080B20] font-bold shadow-[0_0_15px_rgba(54,207,255,0.4)]'
                  : 'bg-[#142B54]/40 text-[#D5E9FF]/70 hover:text-white border border-white/10'
              }`}
            >
              Semua Kategori
            </button>
            {CATEGORIES.filter((c) => c !== 'Keamanan dan Perundungan').map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  setVisibleCount(6);
                }}
                className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer font-medium ${
                  selectedCategory === cat
                    ? 'bg-[#36CFFF] text-[#080B20] font-bold shadow-[0_0_15px_rgba(54,207,255,0.4)]'
                    : 'bg-[#142B54]/40 text-[#D5E9FF]/70 hover:text-white border border-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Loading & Error States */}
        {isLoading && (
          <div className="py-20 text-center text-sm text-[#36CFFF] flex items-center justify-center gap-2">
            <div className="w-5 h-5 rounded-full border-2 border-[#36CFFF] border-t-transparent animate-spin" />
            <span>Memuat aspirasi siswa...</span>
          </div>
        )}

        {loadError && (
          <div className="p-8 rounded-3xl glass-panel text-center max-w-md mx-auto space-y-4">
            <AlertCircle className="w-10 h-10 text-red-400 mx-auto" />
            <p className="text-sm text-red-200">
              Gagal memuat aspirasi. Periksa koneksi internetmu.
            </p>
            <button
              onClick={fetchAspirations}
              className="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-[#36CFFF]/30 border border-[#36CFFF] hover:bg-[#36CFFF]/50 cursor-pointer"
            >
              Coba Lagi
            </button>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !loadError && displayedAspirations.length === 0 && (
          <div className="py-20 text-center glass-panel rounded-3xl p-8 max-w-lg mx-auto">
            <Sparkles className="w-10 h-10 text-[#36CFFF]/40 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white mb-1">
              Aspirasi tidak ditemukan.
            </h3>
            <p className="text-xs text-[#D5E9FF]/60 mb-4">
              {searchQuery
                ? `Tidak ada aspirasi yang cocok dengan kata kunci "${searchQuery}".`
                : 'Belum ada aspirasi terbit untuk kategori ini.'}
            </p>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-[#36CFFF] underline cursor-pointer"
              >
                Hapus pencarian
              </button>
            )}
          </div>
        )}

        {/* Bento Grid: 2 Columns Desktop, 1 Column Mobile per Section 7 */}
        {!isLoading && !loadError && displayedAspirations.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {displayedAspirations.map((asp) => {
              const hasLiked = StorageService.hasDeviceLiked(asp.id, deviceId);
              return (
                <article
                  key={asp.id}
                  onClick={() => handleOpenDetail(asp)}
                  className="group rounded-3xl p-6 glass-panel glass-panel-hover flex flex-col justify-between cursor-pointer border border-[#36CFFF]/20 hover:border-[#36CFFF]/50 relative overflow-hidden transition-all duration-300"
                >
                  <div>
                    {/* Top metadata: Category tag & Status */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="text-xs font-bold uppercase tracking-wider text-[#36CFFF]">
                        {asp.category}
                      </span>
                      {renderStatusBadge(asp.status)}
                    </div>

                    {/* Title */}
                    <h2 className="text-lg font-bold font-display text-white group-hover:text-[#36CFFF] transition-colors mb-2 leading-snug">
                      {asp.title}
                    </h2>

                    {/* Summary 2-line clamp per Section 7 */}
                    <p className="text-xs text-[#D5E9FF]/75 line-clamp-2 leading-relaxed mb-4">
                      {asp.content}
                    </p>
                  </div>

                  {/* Bottom Footer: Date & Actions (Like, Comments, Share) */}
                  <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#D5E9FF]/60">
                    <span className="font-mono text-[11px]">
                      {formatWIBDateOnly(asp.publishedAt || asp.createdAt)}
                    </span>

                    <div className="flex items-center gap-3">
                      {/* Like button */}
                      <button
                        onClick={(e) => handleLike(e, asp.id)}
                        disabled={hasLiked}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                          hasLiked
                            ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                            : 'bg-white/5 border-white/10 hover:border-rose-400 hover:text-rose-300'
                        }`}
                        title={hasLiked ? 'Sudah disukai oleh perangkat ini' : 'Beri Dukungan'}
                      >
                        <Heart
                          className={`w-3.5 h-3.5 ${hasLiked ? 'fill-rose-400 text-rose-400' : 'text-[#D5E9FF]/70'}`}
                        />
                        <span className="font-mono text-[11px] tabular-nums font-semibold">
                          {asp.likesCount}
                        </span>
                      </button>

                      {/* Comments badge */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setCommentTargetAspiration(asp);
                        }}
                        className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 hover:border-[#36CFFF]/40 hover:text-white transition-all cursor-pointer"
                        title="Buka Tanggapan Siswa"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-[#36CFFF]" />
                        <span className="font-mono text-[11px] tabular-nums font-semibold">
                          {asp.commentsCount}
                        </span>
                      </button>

                      {/* WhatsApp Share */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleShareWhatsApp(asp);
                        }}
                        className="p-1 rounded-lg hover:bg-emerald-500/20 hover:text-emerald-400 text-[#D5E9FF]/60 transition-colors cursor-pointer"
                        title="Bagikan ke WhatsApp"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Load More Button: loads 6 more per Section 7 */}
        {!isLoading && !loadError && filteredAspirations.length > visibleCount && (
          <div className="text-center mt-10">
            <button
              onClick={() => setVisibleCount((prev) => prev + 6)}
              className="glass-button-neon px-6 py-3 rounded-2xl text-xs font-bold tracking-wider text-white cursor-pointer"
            >
              Muat Lebih Banyak ({filteredAspirations.length - visibleCount} lagi)
            </button>
          </div>
        )}
      </main>

      {/* POPUP: Floating Holographic Glass Detail Modal (Section 7) */}
      {/* Closed ONLY via X or Escape; click outside does NOT close per spec */}
      {activeAspiration && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="glass-panel w-full max-w-2xl max-h-[92vh] rounded-3xl border border-[#36CFFF]/50 flex flex-col overflow-hidden shadow-2xl relative">
            {/* Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#142B54]/40">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#36CFFF]">
                  {activeAspiration.category}
                </span>
                <span className="text-white/20">·</span>
                {renderStatusBadge(activeAspiration.status)}
              </div>

              <button
                onClick={handleCloseDetail}
                className="p-2 rounded-xl text-[#D5E9FF]/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                title="Tutup Modal (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              <h2 className="text-xl sm:text-2xl font-bold font-display text-white leading-snug">
                {activeAspiration.title}
              </h2>

              {/* Full Content */}
              <div className="p-5 rounded-2xl bg-[#080B20]/50 border border-white/10 text-sm text-[#D5E9FF] leading-relaxed whitespace-pre-wrap">
                {activeAspiration.content}
              </div>

              {/* Optional Photo Attachment */}
              {activeAspiration.attachmentUrl && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-[#36CFFF] uppercase tracking-wider">
                    Foto Lampiran
                  </span>
                  <div className="rounded-2xl overflow-hidden border border-[#36CFFF]/30 max-h-72 bg-black/40 flex items-center justify-center">
                    <img
                      src={activeAspiration.attachmentUrl}
                      alt="Lampiran Aspirasi"
                      className="max-h-72 object-contain w-full"
                    />
                  </div>
                </div>
              )}

              {/* Metadata Card: Date & Review Info (No author identity per Section 7) */}
              <div className="p-4 rounded-2xl bg-[#142B54]/30 border border-[#36CFFF]/20 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 text-[#D5E9FF]/70">
                  <Clock className="w-4 h-4 text-[#36CFFF]" />
                  <span>Diterbitkan: {formatWIBDateTime(activeAspiration.publishedAt || activeAspiration.createdAt)}</span>
                </div>
                <div className="text-[11px] text-[#36CFFF]/80">
                  SMP Negeri 1 Ungaran · Terverifikasi OSIS
                </div>
              </div>
            </div>

            {/* Bottom Actions: Komentar, Like, WhatsApp */}
            <div className="p-4 sm:p-5 border-t border-white/10 bg-[#080B20]/90 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {/* Like Button */}
                <button
                  onClick={(e) => handleLike(e, activeAspiration.id)}
                  disabled={StorageService.hasDeviceLiked(activeAspiration.id, deviceId)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    StorageService.hasDeviceLiked(activeAspiration.id, deviceId)
                      ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                      : 'bg-white/5 border-white/10 hover:border-rose-400 hover:text-rose-300 text-white'
                  }`}
                >
                  <Heart
                    className={`w-4 h-4 ${
                      StorageService.hasDeviceLiked(activeAspiration.id, deviceId)
                        ? 'fill-rose-400 text-rose-400'
                        : ''
                    }`}
                  />
                  <span>{activeAspiration.likesCount} Suka</span>
                </button>

                {/* WhatsApp Share */}
                <button
                  onClick={() => handleShareWhatsApp(activeAspiration)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-500/10 border border-emerald-500/30 hover:bg-emerald-500/20 text-emerald-300 transition-colors cursor-pointer"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Bagikan ke WA</span>
                </button>
              </div>

              {/* Komentar Button -> Opens Comment Modal */}
              <button
                onClick={() => setCommentTargetAspiration(activeAspiration)}
                className="glass-button-neon px-5 py-2 rounded-xl text-xs font-bold text-white flex items-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-[#36CFFF]" />
                <span>Lihat Komentar ({activeAspiration.commentsCount})</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POPUP: Comment Modal */}
      {commentTargetAspiration && (
        <CommentModal
          aspiration={commentTargetAspiration}
          deviceId={deviceId}
          onClose={() => setCommentTargetAspiration(null)}
          onCommentAdded={() => {
            fetchAspirations();
            if (activeAspiration && activeAspiration.id === commentTargetAspiration.id) {
              setActiveAspiration((prev) => (prev ? { ...prev, commentsCount: prev.commentsCount + 1 } : null));
            }
          }}
        />
      )}

      {/* Footer */}
      <footer className="w-full border-t border-white/10 py-6 text-center text-xs text-[#D5E9FF]/50 bg-[#080B20]/80">
        © 2026 SMP Negeri 1 Ungaran · Portal Aspirasi Siswa
      </footer>
    </div>
  );
};
