import React, { useState, useEffect, useMemo } from 'react';
import {
  Aspiration,
  AspirationCategory,
  AspirationStatus,
  Announcement,
  ActivityLog,
  AdminLoginAttempt,
  Comment,
  CATEGORIES
} from '../types';
import { StorageService } from '../services/storage';
import { formatWIBDateTime, formatWIBDateOnly } from '../utils/date';
import { ClockWIB } from './ClockWIB';
import {
  LayoutDashboard,
  FileCheck2,
  Megaphone,
  BarChart3,
  History,
  Settings,
  LogOut,
  User,
  Search,
  Menu,
  X,
  Clock,
  Eye,
  EyeOff,
  Trash2,
  Edit3,
  CheckCircle,
  RefreshCw,
  AlertTriangle,
  Plus,
  ExternalLink,
  ShieldAlert,
  ArrowLeft,
  KeyRound,
  Check,
  ShieldCheck,
  MessageSquare,
  HardDrive
} from 'lucide-react';
import { GoogleDriveExplorer } from './GoogleDriveExplorer';

interface AdminDashboardProps {
  onLogout: () => void;
  onGoToPortal: () => void;
}

type AdminTab =
  | 'dashboard'
  | 'aspirations'
  | 'announcements'
  | 'statistics'
  | 'history'
  | 'settings'
  | 'drive';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onLogout,
  onGoToPortal
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profilePopupOpen, setProfilePopupOpen] = useState(false);

  // Core Data
  const [aspirations, setAspirations] = useState<Aspiration[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  // Filter in "Kelola Aspirasi"
  const [aspirationSubTab, setAspirationSubTab] = useState<'public' | 'private'>('public');
  const [statusFilter, setStatusFilter] = useState<string>('Semua');
  const [categoryFilter, setCategoryFilter] = useState<string>('Semua');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Full-Page Glass Detail View of an Aspiration
  const [selectedAspiration, setSelectedAspiration] = useState<Aspiration | null>(null);

  // Edit Modal State
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [showEditConfirmModal, setShowEditConfirmModal] = useState(false);

  // Status Change Modal State
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [targetStatus, setTargetStatus] = useState<AspirationStatus>('Sedang Ditinjau');
  const [statusNote, setStatusNote] = useState('');

  // Delete Confirm Modal State
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  // Announcement Modal State (Add/Edit)
  const [announcementModalOpen, setAnnouncementModalOpen] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annPublisher, setAnnPublisher] = useState('Admin OSIS');
  const [annIsImportant, setAnnIsImportant] = useState(false);
  const [annLink, setAnnLink] = useState('');
  const [annDeleteConfirmId, setAnnDeleteConfirmId] = useState<string | null>(null);

  // Settings State
  const [currentPasswordInput, setCurrentPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [recoveryCodeVerifyPass, setRecoveryCodeVerifyPass] = useState('');
  const [newGeneratedRecoveryCode, setNewGeneratedRecoveryCode] = useState<string | null>(null);
  const [settingsNotice, setSettingsNotice] = useState<string | null>(null);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const reloadData = () => {
    setAspirations(StorageService.getAdminAspirations());
    setAnnouncements(StorageService.getAnnouncements());
    setActivityLogs(StorageService.getActivityLogs());
  };

  useEffect(() => {
    reloadData();
  }, []);

  // Summary counts per Section 10.1
  const counts = useMemo(() => {
    return {
      waiting: aspirations.filter((a) => a.status === 'Menunggu Ditinjau').length,
      reviewing: aspirations.filter((a) => a.status === 'Sedang Ditinjau').length,
      progress: aspirations.filter((a) => a.status === 'Sedang Ditindaklanjuti').length,
      completed: aspirations.filter((a) => a.status === 'Selesai').length,
      total: aspirations.length,
      published: aspirations.filter((a) => a.isPublished && !a.isPrivate).length,
      privateCount: aspirations.filter((a) => a.isPrivate).length
    };
  }, [aspirations]);

  // 5 Newest Aspirations for Dashboard summary per Section 10.1
  const newestFive = useMemo(() => {
    const sorted = [...aspirations].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return sorted.slice(0, 5);
  }, [aspirations]);

  // Filtered Aspirations for "Kelola Aspirasi"
  const filteredAspirations = useMemo(() => {
    return aspirations.filter((asp) => {
      // Subtab: public vs private
      if (aspirationSubTab === 'public' && asp.isPrivate) return false;
      if (aspirationSubTab === 'private' && !asp.isPrivate) return false;

      // Status filter
      if (statusFilter !== 'Semua' && asp.status !== statusFilter) return false;

      // Category filter
      if (categoryFilter !== 'Semua' && asp.category !== categoryFilter) return false;

      // Search query (title and content per Section 10.2)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchTitle = asp.title.toLowerCase().includes(q);
        const matchContent = asp.content.toLowerCase().includes(q);
        if (!matchTitle && !matchContent) return false;
      }

      return true;
    });
  }, [aspirations, aspirationSubTab, statusFilter, categoryFilter, searchQuery]);

  // Click summary status card to filter per Section 10.1
  const handleSummaryCardClick = (status: AspirationStatus) => {
    setStatusFilter(status);
    setActiveTab('aspirations');
    setSelectedAspiration(null);
  };

  // Open Full-Page Glass Detail
  const openDetail = (asp: Aspiration) => {
    setSelectedAspiration(asp);
    setEditTitle(asp.title);
    setEditContent(asp.content);
    setIsEditing(false);
  };

  // Save changes from Edit with summary confirmation
  const handleSaveEditConfirm = () => {
    if (!selectedAspiration) return;
    const updated = StorageService.updateAspiration(
      selectedAspiration.id,
      {
        title: editTitle.trim(),
        content: editContent.trim()
      },
      'Admin Utama OSIS',
      'Penyuntingan redaksi/ejaan oleh Admin OSIS'
    );
    if (updated) {
      setSelectedAspiration(updated);
      setIsEditing(false);
      setShowEditConfirmModal(false);
      reloadData();
      showToast('Perubahan aspirasi berhasil disimpan.');
    }
  };

  // Change Status with confirmation
  const handleConfirmStatusChange = () => {
    if (!selectedAspiration) return;
    const updated = StorageService.updateAspiration(
      selectedAspiration.id,
      { status: targetStatus },
      'Admin Utama OSIS',
      statusNote.trim() || undefined
    );
    if (updated) {
      setSelectedAspiration(updated);
      setShowStatusModal(false);
      setStatusNote('');
      reloadData();
      showToast(`Status berhasil diubah menjadi "${targetStatus}".`);
    }
  };

  // Toggle Publish / Private
  const handleTogglePublish = (publish: boolean) => {
    if (!selectedAspiration) return;
    const updated = StorageService.updateAspiration(
      selectedAspiration.id,
      {
        isPublished: publish,
        isPrivate: !publish,
        publishedAt: publish ? (selectedAspiration.publishedAt || new Date().toISOString()) : undefined
      },
      'Admin Utama OSIS',
      publish ? 'Aspirasi diterbitkan ke publik' : 'Aspirasi disimpan sebagai privat'
    );
    if (updated) {
      setSelectedAspiration(updated);
      reloadData();
      showToast(publish ? 'Aspirasi kini berstatus PUBLIK.' : 'Aspirasi disimpan sebagai PRIVAT.');
    }
  };

  // Permanent Delete
  const handleConfirmDelete = () => {
    if (!selectedAspiration) return;
    StorageService.deleteAspiration(selectedAspiration.id);
    setShowDeleteModal(false);
    setSelectedAspiration(null);
    reloadData();
    showToast('Aspirasi telah dihapus secara permanen.');
  };

  // Delete Comment (Admin feature per Section 10.3)
  const handleDeleteComment = (commentId: string) => {
    StorageService.deleteComment(commentId);
    reloadData();
    showToast('Komentar tidak pantas berhasil dihapus.');
  };

  // Save Announcement
  const handleSaveAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annContent.trim()) {
      showToast('Judul dan isi pengumuman wajib diisi.');
      return;
    }

    if (editingAnnouncement) {
      StorageService.updateAnnouncement(editingAnnouncement.id, {
        title: annTitle.trim(),
        content: annContent.trim(),
        publisher: annPublisher.trim() || 'Admin OSIS',
        isImportant: annIsImportant,
        externalLink: annLink.trim() || undefined
      });
      showToast('Pengumuman berhasil diperbarui.');
    } else {
      StorageService.addAnnouncement({
        title: annTitle.trim(),
        content: annContent.trim(),
        publisher: annPublisher.trim() || 'Admin OSIS',
        isImportant: annIsImportant,
        images: [],
        externalLink: annLink.trim() || undefined
      });
      showToast('Pengumuman baru berhasil diterbitkan.');
    }

    setAnnouncementModalOpen(false);
    setEditingAnnouncement(null);
    reloadData();
  };

  // Settings: Change Password
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    const config = StorageService.getAdminConfig();
    if (currentPasswordInput !== config.passwordHash) {
      setSettingsNotice('Password saat ini salah.');
      return;
    }
    if (newPasswordInput.length < 6) {
      setSettingsNotice('Password baru minimal 6 karakter.');
      return;
    }

    config.passwordHash = newPasswordInput;
    StorageService.saveAdminConfig(config);
    setCurrentPasswordInput('');
    setNewPasswordInput('');
    setSettingsNotice('Password Admin berhasil diperbarui!');
    showToast('Password Admin berhasil diperbarui.');
  };

  // Settings: Generate & Rotate Recovery Code per Section 11
  const handleResetRecoveryCode = (e: React.FormEvent) => {
    e.preventDefault();
    const config = StorageService.getAdminConfig();
    if (recoveryCodeVerifyPass !== config.passwordHash) {
      setSettingsNotice('Verifikasi password saat ini salah untuk membuat kode pemulihan baru.');
      return;
    }

    // Generate unique recovery code
    const randCode = 'SPENSA-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-RECOVER';
    config.recoveryCode = randCode;
    StorageService.saveAdminConfig(config);
    setNewGeneratedRecoveryCode(randCode);
    setRecoveryCodeVerifyPass('');
    showToast('Kode pemulihan berhasil diperbarui.');
  };

  return (
    <div className="min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between aurora-bg">
      {/* 10.1 Top Navigation (Desktop) & Mobile Hamburger */}
      <header className="w-full border-b border-[#36CFFF]/20 bg-[#080B20]/90 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setActiveTab('dashboard');
                setSelectedAspiration(null);
              }}
              className="text-left cursor-pointer"
            >
              <div className="font-display font-black text-white text-base tracking-wider">
                ADMIN OSIS · SMPN 1 UNGARAN
              </div>
              <div className="text-[10px] text-[#36CFFF] uppercase tracking-widest font-semibold">
                Control Center Aspirasi
              </div>
            </button>
          </div>

          {/* Desktop Nav Links (Section 10.1) */}
          <nav className="hidden lg:flex items-center gap-1 text-xs font-semibold">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'aspirations', label: 'Kelola Aspirasi', icon: FileCheck2 },
              { id: 'announcements', label: 'Informasi Sekolah', icon: Megaphone },
              { id: 'drive', label: 'Google Drive', icon: HardDrive },
              { id: 'statistics', label: 'Laporan Statistik', icon: BarChart3 },
              { id: 'history', label: 'Riwayat Aktivitas', icon: History },
              { id: 'settings', label: 'Pengaturan Admin', icon: Settings }
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id && !selectedAspiration;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as AdminTab);
                    setSelectedAspiration(null);
                  }}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#36CFFF] text-[#080B20] font-bold shadow-[0_0_15px_rgba(54,207,255,0.3)]'
                      : 'text-[#D5E9FF]/70 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right: Clock & Profile Icon */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:block">
              <ClockWIB />
            </div>

            {/* Profile Icon (Section 10.1) */}
            <div className="relative">
              <button
                onClick={() => setProfilePopupOpen(!profilePopupOpen)}
                className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#142B54] to-[#36CFFF]/40 border border-[#36CFFF]/50 flex items-center justify-center text-white cursor-pointer hover:border-[#36CFFF] shadow-sm"
                title="Profil Administrator"
              >
                <User className="w-4 h-4 text-[#36CFFF]" />
              </button>

              {/* Profile Popup */}
              {profilePopupOpen && (
                <div className="absolute right-0 mt-2 w-64 glass-panel rounded-2xl border border-[#36CFFF]/40 p-4 shadow-2xl z-50 animate-scaleUp">
                  <div className="pb-3 border-b border-white/10">
                    <div className="text-xs font-bold text-white">Admin Utama OSIS</div>
                    <div className="text-[11px] text-[#36CFFF]">admin@smpn1ungaran.sch.id</div>
                    <div className="text-[10px] text-[#D5E9FF]/50 mt-1">Sesi Aktif · 2026</div>
                  </div>

                  <div className="py-2 space-y-1">
                    <button
                      onClick={() => {
                        setActiveTab('settings');
                        setSelectedAspiration(null);
                        setProfilePopupOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-xs rounded-xl hover:bg-white/10 text-[#D5E9FF] flex items-center gap-2 cursor-pointer"
                    >
                      <Settings className="w-3.5 h-3.5 text-[#36CFFF]" />
                      <span>Pengaturan Akun</span>
                    </button>
                    <button
                      onClick={() => {
                        onGoToPortal();
                        setProfilePopupOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-xs rounded-xl hover:bg-white/10 text-[#D5E9FF] flex items-center gap-2 cursor-pointer"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-[#876BFF]" />
                      <span>Lihat Portal Siswa</span>
                    </button>
                  </div>

                  <div className="pt-2 border-t border-white/10">
                    <button
                      onClick={onLogout}
                      className="w-full px-3 py-2 text-xs rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-200 border border-red-500/30 flex items-center justify-center gap-2 font-semibold cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Keluar (Logout)</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-white/5 border border-white/10 text-white cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Slide-down Panel */}
        {mobileMenuOpen && (
          <div className="lg:hidden px-4 py-3 bg-[#080B20] border-t border-white/10 space-y-1">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'aspirations', label: 'Kelola Aspirasi', icon: FileCheck2 },
              { id: 'announcements', label: 'Informasi Sekolah', icon: Megaphone },
              { id: 'drive', label: 'Google Drive', icon: HardDrive },
              { id: 'statistics', label: 'Laporan Statistik', icon: BarChart3 },
              { id: 'history', label: 'Riwayat Aktivitas', icon: History },
              { id: 'settings', label: 'Pengaturan Admin', icon: Settings }
            ].map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as AdminTab);
                    setSelectedAspiration(null);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-2.5 px-4 py-2.5 rounded-xl text-xs font-semibold cursor-pointer ${
                    activeTab === item.id && !selectedAspiration
                      ? 'bg-[#36CFFF] text-[#080B20]'
                      : 'text-[#D5E9FF]/80 hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </header>

      {/* Global Toast */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 glass-panel px-4 py-3 rounded-2xl border border-emerald-400/50 bg-[#080B20]/90 text-emerald-200 text-xs flex items-center gap-2 shadow-2xl animate-scaleUp">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 flex-1">
        {/* ========================================================
            VIEW 1: FULL PAGE GLASS DETAIL MODERATION (Section 10.2)
            ======================================================== */}
        {selectedAspiration ? (
          <div className="space-y-6 animate-fadeIn">
            {/* Top Bar Back & Status Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <button
                onClick={() => setSelectedAspiration(null)}
                className="flex items-center gap-2 text-xs font-semibold text-[#36CFFF] hover:text-white bg-white/5 px-3.5 py-2 rounded-xl border border-white/10 cursor-pointer w-fit"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Daftar Aspirasi</span>
              </button>

              <div className="flex flex-wrap items-center gap-2">
                {/* Publish / Private Button */}
                {selectedAspiration.isPublished && !selectedAspiration.isPrivate ? (
                  <button
                    onClick={() => handleTogglePublish(false)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 cursor-pointer"
                  >
                    <EyeOff className="w-3.5 h-3.5" />
                    <span>Simpan Sebagai Privat</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleTogglePublish(true)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Terbitkan ke Publik</span>
                  </button>
                )}

                {/* Ubah Status Button */}
                <button
                  onClick={() => {
                    setTargetStatus(selectedAspiration.status);
                    setShowStatusModal(true);
                  }}
                  className="glass-button-neon flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-[#36CFFF]" />
                  <span>Ubah Status</span>
                </button>

                {/* Hapus Button */}
                <button
                  onClick={() => setShowDeleteModal(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-red-600/20 border border-red-500/30 text-red-200 hover:bg-red-600/30 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                  <span>Hapus</span>
                </button>
              </div>
            </div>

            {/* Main Full Page Glass Card */}
            <div className="glass-panel rounded-3xl p-6 sm:p-8 space-y-6 border border-[#36CFFF]/30">
              {/* Meta Header */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/10 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[#36CFFF] uppercase tracking-wider">
                    {selectedAspiration.category}
                  </span>
                  <span className="text-white/20">·</span>
                  <span className="text-[#D5E9FF]/60 font-mono">
                    ID: {selectedAspiration.id}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-[#142B54] border border-[#36CFFF]/40 text-[#36CFFF]">
                    Status: {selectedAspiration.status}
                  </span>
                  <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${selectedAspiration.isPublished && !selectedAspiration.isPrivate ? 'bg-emerald-500/20 text-emerald-300' : 'bg-white/10 text-[#D5E9FF]/60'}`}>
                    {selectedAspiration.isPublished && !selectedAspiration.isPrivate ? 'PUBLIK' : 'PRIVAT'}
                  </span>
                </div>
              </div>

              {/* Title & Editable view */}
              {isEditing ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#36CFFF] mb-1">
                      Edit Judul (Hanya untuk perbaikan ejaan / sensor nama pribadi)
                    </label>
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#36CFFF]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#36CFFF] mb-1">
                      Edit Isi Uraian
                    </label>
                    <textarea
                      rows={6}
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl p-4 text-sm text-white focus:outline-none focus:border-[#36CFFF] resize-none"
                    />
                  </div>
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => {
                        setIsEditing(false);
                        setEditTitle(selectedAspiration.title);
                        setEditContent(selectedAspiration.content);
                      }}
                      className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      onClick={() => setShowEditConfirmModal(true)}
                      className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#36CFFF]/30 border border-[#36CFFF] hover:bg-[#36CFFF]/50 cursor-pointer"
                    >
                      Simpan Perubahan
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <h1 className="text-xl sm:text-2xl font-bold font-display text-white">
                      {selectedAspiration.title}
                    </h1>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-[#D5E9FF] border border-white/10 cursor-pointer shrink-0"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-[#36CFFF]" />
                      <span>Edit Redaksi</span>
                    </button>
                  </div>

                  <div className="p-5 rounded-2xl bg-[#080B20]/60 border border-white/10 text-sm leading-relaxed whitespace-pre-wrap text-[#D5E9FF]">
                    {selectedAspiration.content}
                  </div>
                </div>
              )}

              {/* Original Content Audit Box (If edited previously per Section 10.2) */}
              {(selectedAspiration.originalTitle || selectedAspiration.originalContent) && (
                <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 text-xs space-y-1.5">
                  <div className="font-bold text-amber-300">
                    Catatan Audit: Konten Asli Siswa Sebelum Diedit
                  </div>
                  {selectedAspiration.originalTitle && (
                    <p className="text-amber-200/80">
                      <strong>Judul Asli:</strong> {selectedAspiration.originalTitle}
                    </p>
                  )}
                  {selectedAspiration.originalContent && (
                    <p className="text-amber-200/80">
                      <strong>Isi Asli:</strong> &ldquo;{selectedAspiration.originalContent}&rdquo;
                    </p>
                  )}
                </div>
              )}

              {/* Photo attachment if available */}
              {selectedAspiration.attachmentUrl && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-[#36CFFF] uppercase tracking-wider">
                    Foto Lampiran Siswa
                  </span>
                  <div className="rounded-2xl overflow-hidden border border-[#36CFFF]/30 max-h-72 bg-black/40 flex items-center justify-center">
                    <img
                      src={selectedAspiration.attachmentUrl}
                      alt="Lampiran Siswa"
                      className="max-h-72 object-contain"
                    />
                  </div>
                </div>
              )}

              {/* Sender Details (Only available in Admin Dashboard, NEVER public per Section 3 & 7) */}
              <div className="p-4 rounded-2xl bg-[#142B54]/40 border border-[#36CFFF]/20 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <span className="text-[#D5E9FF]/60 block mb-0.5">Identitas Pengirim:</span>
                  <span className="font-bold text-white">
                    {selectedAspiration.isAnonymous ? 'Siswa Memilih Anonim' : selectedAspiration.authorName}
                  </span>
                </div>
                <div>
                  <span className="text-[#D5E9FF]/60 block mb-0.5">Kelas:</span>
                  <span className="font-bold text-white">
                    {selectedAspiration.isAnonymous ? 'Tidak Dicantumkan' : `Kelas ${selectedAspiration.authorClass}`}
                  </span>
                </div>
                <div>
                  <span className="text-[#D5E9FF]/60 block mb-0.5">Waktu Masuk:</span>
                  <span className="font-mono text-[#D5E9FF]">
                    {formatWIBDateTime(selectedAspiration.createdAt)}
                  </span>
                </div>
              </div>

              {/* Comment Moderation section for this aspiration per Section 10.3 */}
              <div className="pt-4 border-t border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold font-display text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-[#36CFFF]" />
                    <span>Daftar Tanggapan Siswa ({selectedAspiration.commentsCount})</span>
                  </h3>
                  <span className="text-[11px] text-[#D5E9FF]/50">
                    Admin dapat menghapus tanggapan yang tidak pantas
                  </span>
                </div>

                {StorageService.getComments(selectedAspiration.id).length === 0 ? (
                  <div className="text-xs text-[#D5E9FF]/50 py-3">
                    Belum ada komentar pada aspirasi ini.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {StorageService.getComments(selectedAspiration.id).map((c: Comment) => (
                      <div
                        key={c.id}
                        className="p-3.5 rounded-xl bg-[#080B20]/60 border border-white/10 flex items-start justify-between gap-3 text-xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-[#36CFFF]">{c.nickname}</span>
                            <span className="text-[10px] text-[#D5E9FF]/40 font-mono">
                              {formatWIBDateTime(c.createdAt)}
                            </span>
                          </div>
                          <p className="text-[#D5E9FF]/80">{c.content}</p>
                        </div>

                        <button
                          onClick={() => handleDeleteComment(c.id)}
                          className="p-1.5 rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-300 border border-red-500/30 cursor-pointer shrink-0"
                          title="Hapus Komentar Tidak Pantas Langsung"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : null}

        {/* ========================================================
            TAB 1: DASHBOARD RINGKASAN (Section 10.1)
            ======================================================== */}
        {!selectedAspiration && activeTab === 'dashboard' && (
          <div className="space-y-8 animate-fadeIn">
            {/* Greeting */}
            <div>
              <h1 className="text-2xl sm:text-3xl font-black font-display text-white mb-1">
                Ikhtisar Pengelolaan Aspirasi
              </h1>
              <p className="text-xs sm:text-sm text-[#D5E9FF]/70">
                Pantau status aspirasi masuk, pengumuman sekolah, dan metrik operasional SMP Negeri 1 Ungaran.
              </p>
            </div>

            {/* 4 Kartu Ringkasan Status (Section 10.1) */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {/* Card 1: Menunggu Ditinjau */}
              <button
                onClick={() => handleSummaryCardClick('Menunggu Ditinjau')}
                className="glass-panel p-5 rounded-2xl text-left border-amber-500/30 hover:border-amber-400 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-amber-300 uppercase tracking-wider">
                    Menunggu Ditinjau
                  </span>
                  <Clock className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-3xl sm:text-4xl font-black font-display text-white tabular-nums">
                  {counts.waiting}
                </div>
                <div className="text-[11px] text-[#D5E9FF]/50 mt-1">
                  Aspirasi baru masuk
                </div>
              </button>

              {/* Card 2: Sedang Ditinjau */}
              <button
                onClick={() => handleSummaryCardClick('Sedang Ditinjau')}
                className="glass-panel p-5 rounded-2xl text-left border-[#36CFFF]/30 hover:border-[#36CFFF] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-cyan-300 uppercase tracking-wider">
                    Sedang Ditinjau
                  </span>
                  <Search className="w-4 h-4 text-[#36CFFF]" />
                </div>
                <div className="text-3xl sm:text-4xl font-black font-display text-white tabular-nums">
                  {counts.reviewing}
                </div>
                <div className="text-[11px] text-[#D5E9FF]/50 mt-1">
                  Pemeriksaan Admin OSIS
                </div>
              </button>

              {/* Card 3: Sedang Ditindaklanjuti */}
              <button
                onClick={() => handleSummaryCardClick('Sedang Ditindaklanjuti')}
                className="glass-panel p-5 rounded-2xl text-left border-[#876BFF]/30 hover:border-[#876BFF] transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-purple-300 uppercase tracking-wider">
                    Ditindaklanjuti
                  </span>
                  <RefreshCw className="w-4 h-4 text-[#876BFF]" />
                </div>
                <div className="text-3xl sm:text-4xl font-black font-display text-white tabular-nums">
                  {counts.progress}
                </div>
                <div className="text-[11px] text-[#D5E9FF]/50 mt-1">
                  Diteruskan ke pihak sekolah
                </div>
              </button>

              {/* Card 4: Selesai */}
              <button
                onClick={() => handleSummaryCardClick('Selesai')}
                className="glass-panel p-5 rounded-2xl text-left border-emerald-500/30 hover:border-emerald-400 transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-emerald-300 uppercase tracking-wider">
                    Selesai
                  </span>
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-3xl sm:text-4xl font-black font-display text-white tabular-nums">
                  {counts.completed}
                </div>
                <div className="text-[11px] text-[#D5E9FF]/50 mt-1">
                  Telah terlaksana tuntas
                </div>
              </button>
            </div>

            {/* 5 Aspirasi Terbaru (Section 10.1) */}
            <div className="glass-panel rounded-3xl p-6 sm:p-8 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold font-display text-white">
                    5 Aspirasi Terbaru Masuk
                  </h2>
                  <p className="text-xs text-[#D5E9FF]/60">
                    Klik kartu untuk membuka moderasi dan tindakan lengkap
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('aspirations')}
                  className="text-xs font-semibold text-[#36CFFF] hover:text-white cursor-pointer"
                >
                  Lihat Semua ({counts.total}) →
                </button>
              </div>

              <div className="space-y-3">
                {newestFive.map((asp) => (
                  <div
                    key={asp.id}
                    onClick={() => openDetail(asp)}
                    className="p-4 rounded-2xl bg-[#080B20]/60 hover:bg-[#142B54]/70 border border-white/10 hover:border-[#36CFFF]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer transition-all"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-bold text-[#36CFFF]">{asp.category}</span>
                        <span className="text-white/20">·</span>
                        <span className="text-[#D5E9FF]/50 font-mono text-[11px]">
                          {formatWIBDateTime(asp.createdAt)}
                        </span>
                      </div>
                      <h3 className="text-sm font-bold text-white">{asp.title}</h3>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white/5 border border-white/10 text-white">
                        {asp.status}
                      </span>
                      <span className="text-[#36CFFF] text-xs">Buka →</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 2: KELOLA ASPIRASI (Section 10.2)
            ======================================================== */}
        {!selectedAspiration && activeTab === 'aspirations' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h1 className="text-2xl font-black font-display text-white mb-1">
                Kelola Aspirasi Siswa
              </h1>
              <p className="text-xs text-[#D5E9FF]/70">
                Pemeriksaan, penyuntingan redaksi, penentuan status, dan publikasi aspirasi umum.
              </p>
            </div>

            {/* Subtabs: Publik vs Privat per Section 10.2 */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4 gap-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setAspirationSubTab('public')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    aspirationSubTab === 'public'
                      ? 'bg-[#36CFFF] text-[#080B20] shadow-[0_0_15px_rgba(54,207,255,0.3)]'
                      : 'bg-white/5 text-[#D5E9FF]/70 hover:text-white'
                  }`}
                >
                  Tab Publik ({aspirations.filter((a) => !a.isPrivate).length})
                </button>
                <button
                  onClick={() => setAspirationSubTab('private')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    aspirationSubTab === 'private'
                      ? 'bg-[#36CFFF] text-[#080B20] shadow-[0_0_15px_rgba(54,207,255,0.3)]'
                      : 'bg-white/5 text-[#D5E9FF]/70 hover:text-white'
                  }`}
                >
                  Tab Privat ({aspirations.filter((a) => a.isPrivate).length})
                </button>
              </div>

              <div className="text-xs text-[#D5E9FF]/60 font-mono">
                {filteredAspirations.length} data ditemukan
              </div>
            </div>

            {/* Filters & Search: Judul, Isi, Kategori, Status (Section 10.2) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-1 relative">
                <Search className="w-4 h-4 text-[#36CFFF] absolute left-3.5 top-3 opacity-60" />
                <input
                  type="text"
                  placeholder="Cari judul atau uraian..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl pl-10 pr-3 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#36CFFF]"
                />
              </div>

              <div>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF] cursor-pointer"
                >
                  <option value="Semua">Semua Status</option>
                  <option value="Menunggu Ditinjau">Menunggu Ditinjau</option>
                  <option value="Sedang Ditinjau">Sedang Ditinjau</option>
                  <option value="Sedang Ditindaklanjuti">Sedang Ditindaklanjuti</option>
                  <option value="Selesai">Selesai</option>
                </select>
              </div>

              <div>
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF] cursor-pointer"
                >
                  <option value="Semua">Semua Kategori</option>
                  {CATEGORIES.filter((c) => c !== 'Keamanan dan Perundungan').map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* List Table / Cards */}
            <div className="glass-panel rounded-3xl overflow-hidden border border-[#36CFFF]/20">
              {filteredAspirations.length === 0 ? (
                <div className="py-16 text-center text-xs text-[#D5E9FF]/50">
                  Tidak ada aspirasi yang cocok dengan filter yang dipilih.
                </div>
              ) : (
                <div className="divide-y divide-white/10">
                  {filteredAspirations.map((asp) => (
                    <div
                      key={asp.id}
                      onClick={() => openDetail(asp)}
                      className="p-5 hover:bg-[#142B54]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer transition-colors"
                    >
                      <div className="space-y-1.5 flex-1">
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span className="font-bold text-[#36CFFF]">{asp.category}</span>
                          <span className="text-white/20">·</span>
                          <span className="text-white/60">
                            {asp.isAnonymous ? 'Anonim' : `${asp.authorName} (${asp.authorClass})`}
                          </span>
                          <span className="text-white/20">·</span>
                          <span className="font-mono text-[11px] text-[#D5E9FF]/40">
                            {formatWIBDateOnly(asp.createdAt)}
                          </span>
                        </div>
                        <h3 className="text-sm font-bold text-white hover:text-[#36CFFF]">
                          {asp.title}
                        </h3>
                        <p className="text-xs text-[#D5E9FF]/70 line-clamp-2 max-w-3xl">
                          {asp.content}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="px-3 py-1 rounded-xl text-xs font-semibold bg-[#142B54] border border-white/15 text-white">
                          {asp.status}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${asp.isPublished && !asp.isPrivate ? 'bg-emerald-500/20 text-emerald-300' : 'bg-white/10 text-white/50'}`}>
                          {asp.isPublished && !asp.isPrivate ? 'PUBLIK' : 'PRIVAT'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 3: INFORMASI SEKOLAH (PENGUMUMAN) (Section 9)
            ======================================================== */}
        {!selectedAspiration && activeTab === 'announcements' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-black font-display text-white mb-1">
                  Kelola Informasi & Pengumuman
                </h1>
                <p className="text-xs text-[#D5E9FF]/70">
                  Terbitkan pengumuman resmi sekolah untuk dibaca oleh seluruh siswa.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingAnnouncement(null);
                  setAnnTitle('');
                  setAnnContent('');
                  setAnnPublisher('Admin OSIS');
                  setAnnIsImportant(false);
                  setAnnLink('');
                  setAnnouncementModalOpen(true);
                }}
                className="glass-button-neon px-4 py-2 rounded-xl text-xs font-bold text-white flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4 text-[#36CFFF]" />
                <span>Buat Pengumuman Baru</span>
              </button>
            </div>

            {/* Announcement List for Admin */}
            <div className="glass-panel rounded-3xl overflow-hidden border border-[#36CFFF]/20 divide-y divide-white/10">
              {announcements.length === 0 ? (
                <div className="p-12 text-center text-xs text-[#D5E9FF]/50">
                  Belum ada pengumuman yang diterbitkan.
                </div>
              ) : (
                announcements.map((ann) => (
                  <div
                    key={ann.id}
                    className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2 text-xs">
                        {ann.isImportant && (
                          <span className="text-[10px] font-bold text-cyan-200 bg-[#36CFFF]/20 border border-[#36CFFF]/40 px-2 py-0.5 rounded-full uppercase">
                            PRIORITAS
                          </span>
                        )}
                        <span className="text-[#36CFFF] font-semibold">{ann.publisher}</span>
                        <span className="text-white/20">·</span>
                        <span className="text-[#D5E9FF]/40 font-mono text-[11px]">
                          {formatWIBDateTime(ann.publishedAt)}
                        </span>
                      </div>
                      <h3 className="text-sm font-bold text-white">{ann.title}</h3>
                      <p className="text-xs text-[#D5E9FF]/70 line-clamp-2">{ann.content}</p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          setEditingAnnouncement(ann);
                          setAnnTitle(ann.title);
                          setAnnContent(ann.content);
                          setAnnPublisher(ann.publisher);
                          setAnnIsImportant(ann.isImportant);
                          setAnnLink(ann.externalLink || '');
                          setAnnouncementModalOpen(true);
                        }}
                        className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#36CFFF] border border-white/10 cursor-pointer"
                        title="Edit Pengumuman"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => setAnnDeleteConfirmId(ann.id)}
                        className="p-2 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/30 cursor-pointer"
                        title="Hapus Pengumuman"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 4: LAPORAN STATISTIK (Section 10.4)
            ======================================================== */}
        {!selectedAspiration && activeTab === 'statistics' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h1 className="text-2xl font-black font-display text-white mb-1">
                Laporan Statistik Internal Admin
              </h1>
              <p className="text-xs text-[#D5E9FF]/70">
                Metrik operasional penanganan aspirasi (khusus Admin, tidak dipublikasikan ke siswa).
              </p>
            </div>

            {/* KPI Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="glass-panel p-5 rounded-2xl border-[#36CFFF]/30">
                <span className="text-xs text-[#D5E9FF]/60 block mb-1">Total Aspirasi Diterima</span>
                <span className="text-3xl font-black font-display text-white tabular-nums">{counts.total}</span>
              </div>
              <div className="glass-panel p-5 rounded-2xl border-emerald-500/30">
                <span className="text-xs text-[#D5E9FF]/60 block mb-1">Tingkat Penyelesaian</span>
                <span className="text-3xl font-black font-display text-emerald-400 tabular-nums">
                  {counts.total > 0 ? Math.round((counts.completed / counts.total) * 100) : 0}%
                </span>
              </div>
              <div className="glass-panel p-5 rounded-2xl border-[#876BFF]/30">
                <span className="text-xs text-[#D5E9FF]/60 block mb-1">Aspirasi Berstatus Publik</span>
                <span className="text-3xl font-black font-display text-[#876BFF] tabular-nums">{counts.published}</span>
              </div>
              <div className="glass-panel p-5 rounded-2xl border-amber-500/30">
                <span className="text-xs text-[#D5E9FF]/60 block mb-1">Total Tanggapan Komentar</span>
                <span className="text-3xl font-black font-display text-amber-300 tabular-nums">
                  {StorageService.getComments().length}
                </span>
              </div>
            </div>

            {/* Distribution Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Category Breakdown */}
              <div className="glass-panel p-6 rounded-3xl space-y-4">
                <h3 className="text-sm font-bold font-display text-white">
                  Distribusi Aspirasi Per Kategori
                </h3>
                <div className="space-y-3">
                  {CATEGORIES.filter((c) => c !== 'Keamanan dan Perundungan').map((cat) => {
                    const catCount = aspirations.filter((a) => a.category === cat).length;
                    const pct = counts.total > 0 ? Math.round((catCount / counts.total) * 100) : 0;
                    return (
                      <div key={cat} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-[#D5E9FF]/80">{cat}</span>
                          <span className="text-[#36CFFF] font-mono tabular-nums">{catCount} ({pct}%)</span>
                        </div>
                        <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#36CFFF] to-[#876BFF] rounded-full"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Status Breakdown */}
              <div className="glass-panel p-6 rounded-3xl space-y-4">
                <h3 className="text-sm font-bold font-display text-white">
                  Distribusi Status Aspirasi
                </h3>
                <div className="space-y-3">
                  {[
                    { label: 'Menunggu Ditinjau', count: counts.waiting, color: 'bg-amber-400' },
                    { label: 'Sedang Ditinjau', count: counts.reviewing, color: 'bg-[#36CFFF]' },
                    { label: 'Sedang Ditindaklanjuti', count: counts.progress, color: 'bg-[#876BFF]' },
                    { label: 'Selesai', count: counts.completed, color: 'bg-emerald-400' }
                  ].map((s) => {
                    const pct = counts.total > 0 ? Math.round((s.count / counts.total) * 100) : 0;
                    return (
                      <div key={s.label} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-[#D5E9FF]/80">{s.label}</span>
                          <span className="font-mono tabular-nums text-white">{s.count} ({pct}%)</span>
                        </div>
                        <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                          <div className={`h-full ${s.color} rounded-full`} style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 5: RIWAYAT AKTIVITAS (Section 10.4)
            ======================================================== */}
        {!selectedAspiration && activeTab === 'history' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h1 className="text-2xl font-black font-display text-white mb-1">
                Riwayat Aktivitas & Log Audit
              </h1>
              <p className="text-xs text-[#D5E9FF]/70">
                Catatan mutasi status dan moderasi aspirasi yang tidak dapat diubah oleh dashboard biasa.
              </p>
            </div>

            <div className="glass-panel rounded-3xl overflow-hidden border border-[#36CFFF]/20 divide-y divide-white/10">
              {activityLogs.length === 0 ? (
                <div className="p-12 text-center text-xs text-[#D5E9FF]/50">
                  Belum ada log aktivitas tercatat.
                </div>
              ) : (
                activityLogs.map((log) => (
                  <div key={log.id} className="p-5 flex flex-col sm:flex-row sm:items-start justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{log.aspirationTitle}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-[#36CFFF] font-mono">
                          {log.aspirationId}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[#D5E9FF]/70">
                        <span>Status diubah:</span>
                        <span className="px-1.5 py-0.5 rounded bg-white/5 line-through text-white/50">{log.oldStatus}</span>
                        <span>→</span>
                        <span className="px-1.5 py-0.5 rounded bg-[#36CFFF]/20 text-[#36CFFF] font-semibold">{log.newStatus}</span>
                      </div>
                      {log.note && (
                        <p className="text-[#D5E9FF]/90 italic bg-white/5 p-2 rounded-xl text-[11px] mt-1">
                          Catatan Admin: &ldquo;{log.note}&rdquo;
                        </p>
                      )}
                    </div>

                    <div className="text-right sm:shrink-0 text-[11px] text-[#D5E9FF]/50">
                      <div>Aktor: <strong className="text-white">{log.adminActor}</strong></div>
                      <div className="font-mono mt-0.5">{formatWIBDateTime(log.timestamp)}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 6: PENGATURAN ADMIN (Section 11)
            ======================================================== */}
        {!selectedAspiration && activeTab === 'settings' && (
          <div className="space-y-8 animate-fadeIn max-w-3xl">
            <div>
              <h1 className="text-2xl font-black font-display text-white mb-1">
                Pengaturan Akun & Keamanan Admin
              </h1>
              <p className="text-xs text-[#D5E9FF]/70">
                Kelola kredensial Admin Utama, perbarui kode pemulihan, dan tinjau log keamanan.
              </p>
            </div>

            {settingsNotice && (
              <div className="p-4 rounded-2xl bg-cyan-950/40 border border-[#36CFFF]/40 text-cyan-200 text-xs">
                {settingsNotice}
              </div>
            )}

            {/* 1. Ganti Password */}
            <div className="glass-panel p-6 rounded-3xl border border-[#36CFFF]/30 space-y-4">
              <h3 className="text-sm font-bold font-display text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#36CFFF]" />
                <span>Ganti Password Admin Utama</span>
              </h3>
              <form onSubmit={handleChangePassword} className="space-y-3">
                <div>
                  <label className="block text-xs text-[#D5E9FF]/70 mb-1">Password Saat Ini</label>
                  <input
                    type="password"
                    value={currentPasswordInput}
                    onChange={(e) => setCurrentPasswordInput(e.target.value)}
                    placeholder="Masukkan password lama..."
                    className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#D5E9FF]/70 mb-1">Password Baru (min. 6 karakter)</label>
                  <input
                    type="password"
                    value={newPasswordInput}
                    onChange={(e) => setNewPasswordInput(e.target.value)}
                    placeholder="Masukkan password baru..."
                    className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF]"
                  />
                </div>
                <div className="pt-2 text-right">
                  <button
                    type="submit"
                    className="glass-button-neon px-5 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
                  >
                    Perbarui Password
                  </button>
                </div>
              </form>
            </div>

            {/* 2. Kode Pemulihan (Section 11) */}
            <div className="glass-panel p-6 rounded-3xl border border-[#876BFF]/30 space-y-4">
              <h3 className="text-sm font-bold font-display text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#876BFF]" />
                <span>Perbarui Kode Pemulihan Akun</span>
              </h3>
              <p className="text-xs text-[#D5E9FF]/70">
                Satu kode pemulihan dapat digunakan untuk mereset akun jika terkunci. Mengganti kode akan langsung menonaktifkan kode lama.
              </p>

              {newGeneratedRecoveryCode && (
                <div className="p-4 rounded-2xl bg-[#080B20] border border-emerald-400 text-xs space-y-2">
                  <div className="font-bold text-emerald-400">
                    Kode Pemulihan Baru Anda (Simpan Sekarang):
                  </div>
                  <div className="font-mono text-sm tracking-widest text-white bg-white/10 p-2.5 rounded-xl text-center select-all">
                    {newGeneratedRecoveryCode}
                  </div>
                  <p className="text-[11px] text-[#D5E9FF]/60">
                    Kode ini hanya ditampilkan satu kali demi keamanan.
                  </p>
                </div>
              )}

              <form onSubmit={handleResetRecoveryCode} className="space-y-3">
                <div>
                  <label className="block text-xs text-[#D5E9FF]/70 mb-1">
                    Verifikasi Password Saat Ini untuk Buat Kode Baru
                  </label>
                  <input
                    type="password"
                    value={recoveryCodeVerifyPass}
                    onChange={(e) => setRecoveryCodeVerifyPass(e.target.value)}
                    placeholder="Verifikasi password..."
                    className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF]"
                  />
                </div>
                <div className="pt-2 text-right">
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#876BFF] to-[#36CFFF] cursor-pointer"
                  >
                    Buat Kode Pemulihan Baru
                  </button>
                </div>
              </form>
            </div>

            {/* 3. Login Security Log (Section 11) */}
            <div className="glass-panel p-6 rounded-3xl border border-white/15 space-y-3">
              <h3 className="text-sm font-bold font-display text-white">
                Log Percobaan Login Admin (Keamanan)
              </h3>
              <div className="max-h-48 overflow-y-auto space-y-1.5 text-[11px]">
                {StorageService.getLoginLogs().length === 0 ? (
                  <div className="text-white/40">Belum ada riwayat login tercatat.</div>
                ) : (
                  StorageService.getLoginLogs().map((lg: AdminLoginAttempt, i: number) => (
                    <div key={i} className="flex justify-between items-center p-2 rounded-lg bg-white/5">
                      <span className={lg.success ? 'text-emerald-400' : 'text-red-400'}>
                        {lg.success ? 'Login Berhasil' : 'Login Gagal'}
                      </span>
                      <span className="font-mono text-[#D5E9FF]/50">{formatWIBDateTime(lg.timestamp)}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            TAB 7: GOOGLE DRIVE SEKOLAH (Section 9 & Workspace API)
            ======================================================== */}
        {!selectedAspiration && activeTab === 'drive' && (
          <div className="space-y-6 animate-fadeIn">
            <GoogleDriveExplorer />
          </div>
        )}
      </main>

      {/* POPUP: Edit Confirmation Modal (Section 10.2) */}
      {showEditConfirmModal && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-md w-full rounded-3xl p-6 border border-[#36CFFF]/40 animate-scaleUp">
            <h3 className="text-base font-bold font-display text-white mb-2">
              Konfirmasi Perubahan Redaksi
            </h3>
            <p className="text-xs text-[#D5E9FF]/70 mb-4">
              Pastikan pengeditan tidak mengubah maksud inti aspirasi siswa. Konten asli akan tetap tersimpan dalam log audit.
            </p>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setShowEditConfirmModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleSaveEditConfirm}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-[#36CFFF] text-[#080B20] cursor-pointer"
              >
                Ya, Simpan Perubahan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POPUP: Status Change Modal (Section 10.2) */}
      {showStatusModal && selectedAspiration && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-md w-full rounded-3xl p-6 border border-[#36CFFF]/40 animate-scaleUp space-y-4">
            <h3 className="text-base font-bold font-display text-white">
              Ubah Status Aspirasi
            </h3>

            <div className="p-3 rounded-xl bg-[#080B20]/80 border border-white/10 text-xs flex justify-between items-center">
              <span className="text-[#D5E9FF]/60">Status Lama:</span>
              <span className="font-bold text-white">{selectedAspiration.status}</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#36CFFF] mb-1">
                Pilih Status Baru
              </label>
              <select
                value={targetStatus}
                onChange={(e) => setTargetStatus(e.target.value as AspirationStatus)}
                className="w-full bg-[#142B54]/90 border border-white/20 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-[#36CFFF] cursor-pointer"
              >
                <option value="Menunggu Ditinjau">Menunggu Ditinjau</option>
                <option value="Sedang Ditinjau">Sedang Ditinjau</option>
                <option value="Sedang Ditindaklanjuti">Sedang Ditindaklanjuti</option>
                <option value="Selesai">Selesai</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D5E9FF]/70 mb-1">
                Catatan Perubahan Status (Opsional)
              </label>
              <textarea
                rows={2}
                placeholder="Contoh: Diteruskan ke Wakil Kepala Sekolah bidang Sarpras..."
                value={statusNote}
                onChange={(e) => setStatusNote(e.target.value)}
                className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#36CFFF] resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowStatusModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmStatusChange}
                className="glass-button-neon px-5 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
              >
                Konfirmasi Perubahan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POPUP: Delete Permanent Modal (Section 10.2) */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-md w-full rounded-3xl p-6 border border-red-500/40 animate-scaleUp space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold font-display text-white text-center">
              Yakin ingin menghapus aspirasi ini?
            </h3>
            <p className="text-xs text-[#D5E9FF]/70 text-center">
              Tindakan ini permanen dan akan menghapus aspirasi beserta seluruh tanggapan komentar dari sistem.
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 cursor-pointer"
              >
                Hapus Permanen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POPUP: Add/Edit Announcement Modal */}
      {announcementModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-lg w-full rounded-3xl p-6 sm:p-8 border border-[#36CFFF]/40 animate-scaleUp">
            <h3 className="text-lg font-bold font-display text-white mb-4">
              {editingAnnouncement ? 'Edit Pengumuman Sekolah' : 'Buat Pengumuman Baru'}
            </h3>

            <form onSubmit={handleSaveAnnouncement} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#36CFFF] mb-1">
                  Judul Pengumuman <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={annTitle}
                  onChange={(e) => setAnnTitle(e.target.value)}
                  placeholder="Contoh: Jadwal Ujian Tengah Semester..."
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#36CFFF] mb-1">
                  Nama Penerbit (Fleksibel) <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={annPublisher}
                  onChange={(e) => setAnnPublisher(e.target.value)}
                  placeholder="Contoh: Wakasek Kesiswaan / Pembina OSIS"
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#36CFFF] mb-1">
                  Isi Lengkap Pengumuman <span className="text-red-400">*</span>
                </label>
                <textarea
                  rows={4}
                  value={annContent}
                  onChange={(e) => setAnnContent(e.target.value)}
                  placeholder="Tuliskan isi pengumuman secara rinci..."
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#36CFFF] resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#36CFFF] mb-1">
                  Tautan Eksternal (Opsional, HTTPS)
                </label>
                <input
                  type="url"
                  value={annLink}
                  onChange={(e) => setAnnLink(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF]"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={annIsImportant}
                    onChange={(e) => setAnnIsImportant(e.target.checked)}
                    className="w-4 h-4 rounded text-[#36CFFF] focus:ring-[#36CFFF] bg-[#142B54]"
                  />
                  <span className="text-xs font-bold text-cyan-200">
                    Tandai Sebagai PENTING / PRIORITAS (Tampil paling atas)
                  </span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAnnouncementModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="glass-button-neon px-5 py-2 rounded-xl text-xs font-bold text-white cursor-pointer"
                >
                  Simpan & Terbitkan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* POPUP: Delete Announcement Confirm */}
      {annDeleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-sm w-full rounded-3xl p-6 border border-red-500/40 animate-scaleUp space-y-4">
            <h3 className="text-base font-bold font-display text-white text-center">
              Hapus Pengumuman Ini?
            </h3>
            <p className="text-xs text-[#D5E9FF]/70 text-center">
              Pengumuman akan dihapus permanen dari daftar pengumuman siswa.
            </p>
            <div className="flex items-center justify-center gap-2">
              <button
                onClick={() => setAnnDeleteConfirmId(null)}
                className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/70 bg-white/5 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={() => {
                  StorageService.deleteAnnouncement(annDeleteConfirmId);
                  setAnnDeleteConfirmId(null);
                  reloadData();
                  showToast('Pengumuman berhasil dihapus.');
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-red-600 cursor-pointer"
              >
                Hapus Permanen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full border-t border-white/10 py-4 text-center text-xs text-[#D5E9FF]/40 bg-[#080B20]/90">
        Dashboard Administrator · OSIS SMP Negeri 1 Ungaran
      </footer>
    </div>
  );
};
