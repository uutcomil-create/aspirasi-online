import React, { useState } from 'react';
import { SensitiveReport } from '../types';
import { StorageService } from '../services/storage';
import { formatWIBDateTime } from '../utils/date';
import {
  ShieldAlert,
  Lock,
  ArrowLeft,
  KeyRound,
  CheckCircle,
  Clock,
  User,
  Eye,
  FileText,
  AlertCircle
} from 'lucide-react';

interface SafeguardingPortalProps {
  onBackToPortal: () => void;
}

export const SafeguardingPortal: React.FC<SafeguardingPortalProps> = ({
  onBackToPortal
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const [reports, setReports] = useState<SensitiveReport[]>([]);
  const [selectedReport, setSelectedReport] = useState<SensitiveReport | null>(null);
  const [handlingNote, setHandlingNote] = useState('');

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    try {
      const data = StorageService.getSensitiveReportsForAuthorizedStaff(pinInput.trim());
      setReports(data);
      setIsAuthenticated(true);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'PIN tidak valid.';
      setAuthError(msg);
    }
  };

  const handleUpdateStatus = (status: 'Baru Masuk' | 'Dalam Penanganan BK' | 'Selesai') => {
    if (!selectedReport) return;
    const all = StorageService.getSensitiveReportsForAuthorizedStaff('1975bk');
    const idx = all.findIndex((r: SensitiveReport) => r.id === selectedReport.id);
    if (idx !== -1) {
      all[idx].status = status;
      if (handlingNote.trim()) {
        all[idx].officerNotes = handlingNote.trim();
      }
      all[idx].handledBy = 'Guru BK SMPN 1 Ungaran';
      localStorage.setItem('smpn1ungaran_sensitive_safeguard_v1', JSON.stringify(all));
      setSelectedReport({ ...all[idx] });
      setReports([...all]);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between items-center p-4 aurora-bg">
      {/* Top Navbar */}
      <div className="w-full max-w-5xl pt-4 flex items-center justify-between">
        <button
          onClick={onBackToPortal}
          className="flex items-center gap-2 text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 px-3.5 py-1.5 rounded-xl border border-white/10 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-[#36CFFF]" />
          <span>Kembali ke Beranda</span>
        </button>

        <div className="flex items-center gap-2 text-xs text-red-400 font-semibold">
          <ShieldAlert className="w-4 h-4" />
          <span>Kanal Safeguarding & BK Sekolah</span>
        </div>
      </div>

      {!isAuthenticated ? (
        // PIN Verification Gate
        <div className="w-full max-w-md glass-panel rounded-3xl p-6 sm:p-8 border border-red-500/40 shadow-2xl relative my-auto">
          <div className="text-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-red-950/60 border border-red-500/50 flex items-center justify-center text-red-400 mx-auto mb-3 shadow-[0_0_25px_rgba(239,68,68,0.25)]">
              <Lock className="w-7 h-7" />
            </div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-red-400">
              Jalur Tertutup & Terenkripsi
            </span>
            <h1 className="text-xl sm:text-2xl font-bold font-display text-white mt-1">
              Verifikasi Guru BK & Petugas
            </h1>
            <p className="text-xs text-[#D5E9FF]/70 mt-1.5 leading-relaxed">
              Jalur ini dikhususkan bagi Guru Bimbingan Konseling (BK) untuk menangani laporan <strong>Keamanan dan Perundungan</strong>. Terisolasi total dari Admin OSIS.
            </p>
          </div>

          {authError && (
            <div className="mb-4 p-3 rounded-xl bg-red-900/30 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          <form onSubmit={handleVerifyPin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#D5E9FF]/80 mb-1.5">
                Masukkan PIN Otorisasi Safeguarding
              </label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="PIN Guru BK..."
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  className="w-full bg-[#142B54]/80 border border-red-500/30 rounded-xl pl-4 pr-10 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-red-400"
                />
                <KeyRound className="w-4 h-4 text-red-400 absolute right-3.5 top-3.5 opacity-70" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl text-xs font-bold tracking-wider text-white bg-gradient-to-r from-red-600 to-purple-600 hover:from-red-500 hover:to-purple-500 shadow-lg cursor-pointer transition-all"
            >
              Buka Konsol Safeguarding
            </button>
          </form>

          <div className="mt-6 p-3 rounded-xl bg-white/5 border border-white/10 text-[11px] text-[#D5E9FF]/60 text-center">
            Demo PIN Petugas BK: <code className="text-red-300 font-bold">1975bk</code> atau <code className="text-[#36CFFF] font-bold">guru-bk</code>
          </div>
        </div>
      ) : (
        // Safeguarding Reports Console
        <div className="w-full max-w-5xl my-8 space-y-6 animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 glass-panel p-6 rounded-3xl border border-red-500/30">
            <div>
              <span className="text-[10px] font-bold text-red-400 uppercase tracking-widest">
                SMP NEGERI 1 UNGARAN · UNIT LAYANAN BK
              </span>
              <h1 className="text-xl sm:text-2xl font-bold font-display text-white">
                Konsol Laporan Keamanan & Perundungan
              </h1>
              <p className="text-xs text-[#D5E9FF]/70 mt-1">
                Data sensitif siswa diisolasi dan hanya dapat diakses oleh petugas bimbingan konseling yang berwenang.
              </p>
            </div>

            <button
              onClick={() => setIsAuthenticated(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-[#D5E9FF] border border-white/10 cursor-pointer self-start sm:self-center"
            >
              Kunci Sesi
            </button>
          </div>

          {/* Reports List */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1 glass-panel rounded-3xl p-4 border border-white/10 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#36CFFF] px-2">
                Daftar Laporan ({reports.length})
              </h3>

              {reports.length === 0 ? (
                <div className="p-8 text-center text-xs text-[#D5E9FF]/50">
                  Belum ada laporan keamanan atau perundungan yang masuk.
                </div>
              ) : (
                <div className="space-y-2">
                  {reports.map((r) => (
                    <button
                      key={r.id}
                      onClick={() => {
                        setSelectedReport(r);
                        setHandlingNote(r.officerNotes || '');
                      }}
                      className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer ${
                        selectedReport?.id === r.id
                          ? 'bg-[#142B54] border-red-400 shadow-md'
                          : 'bg-white/5 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${r.status === 'Selesai' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
                          {r.status}
                        </span>
                        <span className="text-[10px] text-[#D5E9FF]/50 font-mono">
                          {formatWIBDateTime(r.createdAt).split('·')[0]}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-white truncate">{r.title}</div>
                      <div className="text-[11px] text-[#D5E9FF]/60 mt-0.5">
                        {r.isAnonymous ? 'Anonim' : `${r.reporterName} (${r.reporterClass})`}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Selected Report Details */}
            <div className="md:col-span-2 glass-panel rounded-3xl p-6 border border-white/10">
              {selectedReport ? (
                <div className="space-y-5 animate-fadeIn">
                  <div className="flex items-center justify-between pb-4 border-b border-white/10">
                    <div>
                      <span className="text-xs font-bold text-red-400 uppercase tracking-wider">
                        Laporan Rahasia ID: {selectedReport.id}
                      </span>
                      <h2 className="text-lg font-bold text-white mt-1">
                        {selectedReport.title}
                      </h2>
                    </div>

                    <span className="px-3 py-1 rounded-xl text-xs font-semibold bg-red-950/60 border border-red-500/40 text-red-300">
                      {selectedReport.status}
                    </span>
                  </div>

                  {/* Sender Details */}
                  <div className="p-4 rounded-2xl bg-[#080B20]/60 border border-white/10 grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[#D5E9FF]/60 block mb-0.5">Pelapor:</span>
                      <span className="font-bold text-white">
                        {selectedReport.isAnonymous ? 'Siswa Memilih Anonim' : selectedReport.reporterName}
                      </span>
                    </div>
                    <div>
                      <span className="text-[#D5E9FF]/60 block mb-0.5">Kelas:</span>
                      <span className="font-bold text-white">
                        {selectedReport.isAnonymous ? 'Dirahasiakan' : `Kelas ${selectedReport.reporterClass}`}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div>
                    <label className="block text-xs font-semibold text-[#36CFFF] mb-1.5 uppercase tracking-wider">
                      Uraian Kejadian:
                    </label>
                    <div className="p-4 rounded-2xl bg-[#080B20]/80 border border-white/10 text-xs text-[#D5E9FF] leading-relaxed whitespace-pre-wrap">
                      {selectedReport.content}
                    </div>
                  </div>

                  {/* Photos */}
                  {selectedReport.attachmentUrls && selectedReport.attachmentUrls.length > 0 && (
                    <div>
                      <label className="block text-xs font-semibold text-[#36CFFF] mb-1.5 uppercase tracking-wider">
                        Bukti Foto ({selectedReport.attachmentUrls.length}):
                      </label>
                      <div className="grid grid-cols-3 gap-3">
                        {selectedReport.attachmentUrls.map((url, i) => (
                          <div key={i} className="rounded-xl overflow-hidden border border-white/15">
                            <img src={url} alt={`Bukti ${i + 1}`} className="w-full h-24 object-cover" />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Action handling */}
                  <div className="pt-4 border-t border-white/10 space-y-3">
                    <label className="block text-xs font-semibold text-white">
                      Catatan Penanganan Guru BK:
                    </label>
                    <textarea
                      rows={3}
                      value={handlingNote}
                      onChange={(e) => setHandlingNote(e.target.value)}
                      placeholder="Catat tindakan pemanggilan, mediasi, atau bimbingan konseling..."
                      className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-[#36CFFF] resize-none"
                    />

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        onClick={() => handleUpdateStatus('Dalam Penanganan BK')}
                        className="px-4 py-2 rounded-xl text-xs font-bold bg-[#876BFF]/20 border border-[#876BFF] text-[#876BFF] hover:bg-[#876BFF]/30 cursor-pointer"
                      >
                        Tandai Sedang Ditangani BK
                      </button>

                      <button
                        onClick={() => handleUpdateStatus('Selesai')}
                        className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500/20 border border-emerald-400 text-emerald-300 hover:bg-emerald-500/30 cursor-pointer"
                      >
                        Tandai Kasus Selesai
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-24 text-center text-xs text-[#D5E9FF]/50">
                  Pilih salah satu laporan dari panel sebelah kiri untuk meninjau rinciannya.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full py-4 text-center text-xs text-[#D5E9FF]/40">
        © 2026 SMP Negeri 1 Ungaran · Bimbingan Konseling & Layanan Pengaduan Ramah Anak
      </footer>
    </div>
  );
};
