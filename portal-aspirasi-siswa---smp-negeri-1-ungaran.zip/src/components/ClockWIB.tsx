import React, { useState, useEffect } from 'react';
import { getCurrentWIBString } from '../utils/date';
import { Clock } from 'lucide-react';

export const ClockWIB: React.FC = () => {
  const [timeStr, setTimeStr] = useState<string>(getCurrentWIBString());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeStr(getCurrentWIBString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center gap-2 text-xs font-medium text-[#36CFFF] bg-[#142B54]/50 border border-[#36CFFF]/25 px-3 py-1.5 rounded-xl backdrop-blur-md">
      <Clock className="w-3.5 h-3.5 text-[#36CFFF] animate-pulse" />
      <span className="tabular-nums tracking-wide font-mono text-[11px] sm:text-xs">
        {timeStr}
      </span>
    </div>
  );
};
