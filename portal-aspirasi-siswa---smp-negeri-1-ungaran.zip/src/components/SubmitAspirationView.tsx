import React, { useState } from 'react';
import {
  CATEGORIES,
  STUDENT_CLASSES,
  AspirationCategory
} from '../types';
import { StorageService } from '../services/storage';
import { ClockWIB } from './ClockWIB';
import {
  ArrowLeft,
  ShieldAlert,
  User,
  EyeOff,
  Image as ImageIcon,
  CheckCircle2,
  AlertTriangle,
  X,
  UploadCloud,
  FileCheck,
  HardDrive
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GoogleDriveExplorer } from './GoogleDriveExplorer';
import { DriveFileItem } from '../services/googleDriveApi';

interface SubmitAspirationViewProps {
  onBackToDashboard: () => void;
  onSubmittedSuccess: () => void;
}

export const SubmitAspirationView: React.FC<SubmitAspirationViewProps> = ({
  onBackToDashboard,
  onSubmittedSuccess
}) => {
  // Mode: 'general' | 'secret'
  const [formMode, setFormMode] = useState<'general' | 'secret'>('general');

  // Secret Popup warning trigger
  const [showSecretModalNotice, setShowSecretModalNotice] = useState(false);

  // Form states
  const [selectedCategory, setSelectedCategory] = useState<AspirationCategory>('Sarana dan Prasarana');
  const [isAnonymous, setIsAnonymous] = useState<boolean>(false);
  const [authorName, setAuthorName] = useState<string>('');
  const [authorClass, setAuthorClass] = useState<string>('8A');
  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');

  // Attachments
  const [attachmentPreview, setAttachmentPreview] = useState<string | null>(null);
  const [driveAttachedFile, setDriveAttachedFile] = useState<DriveFileItem | null>(null);
  const [secretAttachmentPreviews, setSecretAttachmentPreviews] = useState<string[]>([]);
  const [showDrivePicker, setShowDrivePicker] = useState(false);

  // Confirmation & Modals
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Handle Category Change
  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value as AspirationCategory;
    if (val === 'Keamanan dan Perundungan') {
      setShowSecretModalNotice(true);
    } else {
      setSelectedCategory(val);
      setFormMode('general');
    }
  };

  // Switch to Secret Safeguarding Form
  const proceedToSecretForm = () => {
    setShowSecretModalNotice(false);
    setSelectedCategory('Keamanan dan Perundungan');
    setFormMode('secret');
    setTitle('');
    setContent('');
  };

  // Handle single photo upload for General Aspiration
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setValidationError('Hanya format JPG, PNG, atau WebP yang diperbolehkan.');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setValidationError('Ukuran foto maksimal 5 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setAttachmentPreview(reader.result as string);
      setValidationError(null);
    };
    reader.readAsDataURL(file);
  };

  // Handle multiple photos for Secret Safeguarding (up to 3 photos, max 5MB each)
  const handleSecretPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (secretAttachmentPreviews.length + files.length > 3) {
      setValidationError('Maksimal lampiran adalah 3 foto.');
      return;
    }

    const validFiles: File[] = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) {
        setValidationError('Semua foto harus format JPG, PNG, atau WebP.');
        return;
      }
      if (f.size > 5 * 1024 * 1024) {
        setValidationError(`Foto "${f.name}" melebihi batas 5 MB.`);
        return;
      }
      validFiles.push(f);
    }

    setValidationError(null);
    validFiles.forEach((f) => {
      const reader = new FileReader();
      reader.onload = () => {
        setSecretAttachmentPreviews((prev) => [...prev, reader.result as string].slice(0, 3));
      };
      reader.readAsDataURL(f);
    });
  };

  // Validation
  const validateForm = (): boolean => {
    setValidationError(null);

    if (!isAnonymous) {
      if (!authorName.trim()) {
        setValidationError('Silakan isi nama lengkap kamu atau pilih mode Anonim.');
        return false;
      }
      if (!authorClass) {
        setValidationError('Silakan pilih kelas kamu.');
        return false;
      }
    }

    if (title.trim().length < 5 || title.trim().length > 100) {
      setValidationError('Judul harus antara 5 hingga 100 karakter.');
      return false;
    }

    if (content.trim().length < 20 || content.trim().length > 1000) {
      setValidationError('Isi uraian harus antara 20 hingga 1.000 karakter.');
      return false;
    }

    if (formMode === 'general' && !agreedTerms) {
      setValidationError('Harap setujui pernyataan kebenaran aspirasi.');
      return false;
    }

    return true;
  };

  const handlePreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setShowConfirmModal(true);
    }
  };

  const handleExecuteSubmit = () => {
    setIsSubmitting(true);
    setShowConfirmModal(false);

    try {
      if (formMode === 'secret') {
        // Submit to strictly isolated safeguarding store
        StorageService.addSensitiveReport({
          isAnonymous,
          reporterName: isAnonymous ? undefined : authorName.trim(),
          reporterClass: isAnonymous ? undefined : authorClass,
          title: title.trim(),
          content: content.trim(),
          attachmentUrls: secretAttachmentPreviews
        });

        setSuccessMessage('Laporan berhasil dikirim. Terima kasih telah berani menyampaikan laporan.');
      } else {
        // Submit to General Aspirations
        StorageService.addAspiration({
          category: selectedCategory,
          isAnonymous,
          authorName: isAnonymous ? undefined : authorName.trim(),
          authorClass: isAnonymous ? undefined : authorClass,
          title: title.trim(),
          content: content.trim(),
          attachmentUrl: attachmentPreview || undefined
        });

        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 }
        });

        setSuccessMessage('Aspirasi berhasil dikirim. Terima kasih sudah menyampaikan pendapatmu!');
      }

      setShowSuccessModal(true);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Terjadi kendala saat mengirim. Coba lagi.';
      setValidationError(errorMsg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFinishSuccess = () => {
    setShowSuccessModal(false);
    onSubmittedSuccess();
  };

  return (
    <div className="min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between aurora-bg animate-fadeIn">
      {/* Top Navbar */}
      <header className="w-full border-b border-[#36CFFF]/15 bg-[#080B20]/80 backdrop-blur-xl sticky top-0 z-30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <button
            onClick={onBackToDashboard}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#142B54]/60 hover:bg-[#142B54] border border-[#36CFFF]/30 text-xs text-[#D5E9FF] hover:text-white transition-all cursor-pointer group shadow-sm"
          >
            <ArrowLeft className="w-4 h-4 text-[#36CFFF] group-hover:-translate-x-0.5 transition-transform" />
            <span className="font-medium">Kembali ke Dashboard</span>
          </button>

          <ClockWIB />
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-3xl w-full mx-auto px-4 sm:px-6 py-8 flex-1">
        {/* Banner indicator */}
        {formMode === 'secret' ? (
          <div className="mb-6 rounded-2xl p-4 bg-gradient-to-r from-red-950/50 via-[#142B54]/60 to-purple-950/50 border border-red-500/40 backdrop-blur-md flex items-center gap-3">
            <ShieldAlert className="w-6 h-6 text-red-400 shrink-0" />
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-red-400">
                Jalur Rahasia: Keamanan dan Perundungan
              </div>
              <p className="text-xs text-[#D5E9FF]/80">
                Laporan ini dienkripsi & hanya dapat ditangani oleh Guru Bimbingan Konseling (BK) / Petugas Sekolah yang berwenang. Admin OSIS tidak memiliki akses.
              </p>
            </div>
            <button
              onClick={() => {
                setFormMode('general');
                setSelectedCategory('Sarana dan Prasarana');
              }}
              className="ml-auto text-[11px] underline text-[#36CFFF] hover:text-white shrink-0 cursor-pointer"
            >
              Ubah ke Umum
            </button>
          </div>
        ) : (
          <div className="mb-8">
            <h1 className="text-2xl sm:text-3xl font-black font-display text-white mb-2">
              Kirim Aspirasi Siswa
            </h1>
            <p className="text-sm text-[#D5E9FF]/70">
              Sampaikan ide dan aspirasi untuk kemajuan SMP Negeri 1 Ungaran. Aspirasi umum akan ditinjau oleh Admin OSIS sebelum diterbitkan.
            </p>
          </div>
        )}

        {/* Validation Error Banner */}
        {validationError && (
          <div className="mb-6 p-4 rounded-xl bg-red-900/30 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{validationError}</span>
          </div>
        )}

        {/* Form Box */}
        <form onSubmit={handlePreSubmit} className="glass-panel rounded-3xl p-6 sm:p-8 space-y-6">
          {/* 1. Kategori (Dropdown Glass) */}
          <div>
            <label className="block text-xs font-semibold text-[#36CFFF] uppercase tracking-wider mb-2">
              Kategori Aspirasi <span className="text-red-400">*</span>
            </label>
            <select
              value={selectedCategory}
              onChange={handleCategoryChange}
              className="w-full bg-[#142B54]/80 border border-[#36CFFF]/30 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#36CFFF] focus:ring-1 focus:ring-[#36CFFF] transition-all cursor-pointer"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat} className="bg-[#080B20] text-white">
                  {cat} {cat === 'Keamanan dan Perundungan' ? '(Jalur Rahasia)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Pilihan Identitas: Interaktif 2 Kartu (Dengan Identitas vs Anonim) */}
          <div>
            <label className="block text-xs font-semibold text-[#36CFFF] uppercase tracking-wider mb-2">
              Pilihan Identitas Pengirim <span className="text-red-400">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Kartu: Dengan Identitas */}
              <button
                type="button"
                onClick={() => setIsAnonymous(false)}
                className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                  !isAnonymous
                    ? 'bg-[#142B54] border-[#36CFFF] shadow-[0_0_20px_rgba(54,207,255,0.2)]'
                    : 'bg-[#142B54]/30 border-white/10 hover:border-white/30 text-[#D5E9FF]/60'
                }`}
              >
                <div className={`p-2 rounded-xl ${!isAnonymous ? 'bg-[#36CFFF]/20 text-[#36CFFF]' : 'bg-white/5 text-white/40'}`}>
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <div className={`text-sm font-bold ${!isAnonymous ? 'text-white' : 'text-[#D5E9FF]/70'}`}>
                    Dengan Identitas
                  </div>
                  <div className="text-xs text-[#D5E9FF]/60 mt-0.5">
                    Nama dan kelas dicantumkan untuk verifikasi.
                  </div>
                </div>
              </button>

              {/* Kartu: Anonim */}
              <button
                type="button"
                onClick={() => setIsAnonymous(true)}
                className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all cursor-pointer ${
                  isAnonymous
                    ? 'bg-[#142B54] border-[#36CFFF] shadow-[0_0_20px_rgba(54,207,255,0.2)]'
                    : 'bg-[#142B54]/30 border-white/10 hover:border-white/30 text-[#D5E9FF]/60'
                }`}
              >
                <div className={`p-2 rounded-xl ${isAnonymous ? 'bg-[#36CFFF]/20 text-[#36CFFF]' : 'bg-white/5 text-white/40'}`}>
                  <EyeOff className="w-5 h-5" />
                </div>
                <div>
                  <div className={`text-sm font-bold ${isAnonymous ? 'text-white' : 'text-[#D5E9FF]/70'}`}>
                    Anonim
                  </div>
                  <div className="text-xs text-[#D5E9FF]/60 mt-0.5">
                    Identitas tidak dicantumkan ke publik.
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Nama dan Kelas (Hanya muncul jika Dengan Identitas) */}
          {!isAnonymous && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 animate-fadeIn">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#D5E9FF]/80 mb-1.5">
                  Nama Lengkap Siswa <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Dimas Arya Pratama"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#36CFFF]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#D5E9FF]/80 mb-1.5">
                  Kelas (27 Kelas) <span className="text-red-400">*</span>
                </label>
                <select
                  value={authorClass}
                  onChange={(e) => setAuthorClass(e.target.value)}
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#36CFFF] cursor-pointer"
                >
                  {STUDENT_CLASSES.map((cls) => (
                    <option key={cls} value={cls} className="bg-[#080B20] text-white">
                      Kelas {cls}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* 3. Judul Aspirasi (5 - 100 karakter) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-[#36CFFF] uppercase tracking-wider">
                Judul {formMode === 'secret' ? 'Laporan' : 'Aspirasi'} <span className="text-red-400">*</span>
              </label>
              <span className={`text-[11px] tabular-nums ${title.length > 100 ? 'text-red-400' : 'text-[#D5E9FF]/50'}`}>
                {title.length}/100 karakter (min. 5)
              </span>
            </div>
            <input
              type="text"
              placeholder={
                formMode === 'secret'
                  ? 'Contoh: Dugaan pemalakan di koridor lantai 2 saat jam istirahat'
                  : 'Contoh: Perbaikan proyektor dan kabel LCD di Lab Komputer 2'
              }
              value={title}
              maxLength={100}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#36CFFF]"
            />
          </div>

          {/* 4. Isi Aspirasi (20 - 1.000 karakter) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-[#36CFFF] uppercase tracking-wider">
                Uraian Lengkap <span className="text-red-400">*</span>
              </label>
              <span className={`text-[11px] tabular-nums ${content.length > 1000 ? 'text-red-400' : 'text-[#D5E9FF]/50'}`}>
                {content.length}/1.000 karakter (min. 20)
              </span>
            </div>
            <textarea
              rows={5}
              placeholder={
                formMode === 'secret'
                  ? 'Uraikan secara jelas kejadian, waktu perkiraan, dan pihak yang terlibat jika mengetahui. Data dirahasiakan dan hanya ditangani oleh Guru BK sekolah.'
                  : 'Jelaskan usulan atau masukanmu secara sopan dan konstruktif demi kemajuan bersama SMP Negeri 1 Ungaran...'
              }
              value={content}
              maxLength={1000}
              onChange={(e) => setContent(e.target.value)}
              className="w-full bg-[#142B54]/60 border border-white/20 rounded-xl p-4 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#36CFFF] resize-none"
            />
          </div>

          {/* 5. Lampiran Foto Opsional */}
          <div>
            <label className="block text-xs font-semibold text-[#36CFFF] uppercase tracking-wider mb-2">
              Lampiran Foto Opsional (JPG, PNG, WebP)
            </label>

            {formMode === 'general' ? (
              // Single photo upload for general
              <div>
                {attachmentPreview ? (
                  <div className="relative inline-block rounded-xl overflow-hidden border border-[#36CFFF]/40 group">
                    <img
                      src={attachmentPreview}
                      alt="Pratinjau lampiran"
                      className="w-48 h-32 object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setAttachmentPreview(null);
                        setDriveAttachedFile(null);
                      }}
                      className="absolute top-2 right-2 p-1.5 rounded-full bg-red-600/80 hover:bg-red-600 text-white cursor-pointer"
                      title="Hapus foto"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                    {driveAttachedFile && (
                      <div className="absolute bottom-0 inset-x-0 bg-[#080B20]/90 p-2 text-[10px] text-[#36CFFF] truncate">
                        Google Drive: {driveAttachedFile.name}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-white/20 hover:border-[#36CFFF]/50 rounded-2xl cursor-pointer bg-[#142B54]/20 hover:bg-[#142B54]/40 transition-colors">
                      <UploadCloud className="w-8 h-8 text-[#36CFFF]/70 mb-2" />
                      <span className="text-xs text-[#D5E9FF]/80 font-medium">
                        Klik untuk mengunggah foto dari perangkat
                      </span>
                      <span className="text-[10px] text-[#D5E9FF]/40 mt-1">
                        Maksimal 5 MB · JPG, PNG, atau WebP
                      </span>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={handlePhotoUpload}
                        className="hidden"
                      />
                    </label>

                    <div className="flex items-center justify-center gap-2">
                      <span className="text-[11px] text-[#D5E9FF]/40">atau</span>
                      <button
                        type="button"
                        onClick={() => setShowDrivePicker(true)}
                        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#142B54]/80 hover:bg-[#142B54] border border-[#36CFFF]/40 text-xs font-semibold text-[#36CFFF] hover:text-white transition-all cursor-pointer shadow-sm"
                      >
                        <HardDrive className="w-4 h-4 text-[#36CFFF]" />
                        <span>Pilih Berkas dari Google Drive</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              // Multiple photos upload for Secret Safeguarding (up to 3 photos, max 5MB each)
              <div className="space-y-3">
                <div className="flex flex-wrap gap-3">
                  {secretAttachmentPreviews.map((imgUrl, i) => (
                    <div key={i} className="relative rounded-xl overflow-hidden border border-red-400/40 group">
                      <img src={imgUrl} alt={`Bukti ${i + 1}`} className="w-28 h-24 object-cover" />
                      <button
                        type="button"
                        onClick={() => {
                          setSecretAttachmentPreviews((prev) => prev.filter((_, idx) => idx !== i));
                        }}
                        className="absolute top-1.5 right-1.5 p-1 rounded-full bg-red-600 text-white cursor-pointer"
                        title="Hapus"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}

                  {secretAttachmentPreviews.length < 3 && (
                    <label className="w-28 h-24 flex flex-col items-center justify-center border-2 border-dashed border-red-400/30 hover:border-red-400 rounded-xl cursor-pointer bg-red-950/20 hover:bg-red-950/40 transition-colors">
                      <ImageIcon className="w-6 h-6 text-red-400 mb-1" />
                      <span className="text-[10px] text-red-200">Tambah Foto</span>
                      <span className="text-[9px] text-[#D5E9FF]/50">({secretAttachmentPreviews.length}/3)</span>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        multiple
                        onChange={handleSecretPhotoUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* 6. Checkbox Persetujuan (Wajib untuk Aspirasi Umum per Section 5.2) */}
          {formMode === 'general' && (
            <div className="pt-2">
              <label className="flex items-start gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={agreedTerms}
                  onChange={(e) => setAgreedTerms(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded border-white/30 text-[#36CFFF] focus:ring-[#36CFFF] bg-[#142B54]"
                />
                <span className="text-xs text-[#D5E9FF]/80 leading-relaxed">
                  Saya menyatakan bahwa aspirasi ini dibuat dengan sungguh-sungguh menggunakan bahasa yang santun, bertanggung jawab, dan bertujuan untuk memajukan SMP Negeri 1 Ungaran.
                </span>
              </label>
            </div>
          )}

          {/* Action Button */}
          <div className="pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onBackToDashboard}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-[#D5E9FF]/70 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              Batal
            </button>

            <button
              type="submit"
              disabled={isSubmitting || (formMode === 'general' && !agreedTerms)}
              className="glass-button-neon px-6 py-2.5 rounded-xl text-xs font-bold tracking-wider text-white flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:pointer-events-none"
            >
              <FileCheck className="w-4 h-4 text-[#36CFFF]" />
              <span>{formMode === 'secret' ? 'Kirim Laporan Rahasia' : 'Tinjau & Kirim Aspirasi'}</span>
            </button>
          </div>
        </form>
      </main>

      {/* POPUP 1: Notice Jalur Rahasia (Section 6) */}
      {showSecretModalNotice && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-md w-full rounded-3xl p-6 sm:p-8 border border-red-500/40 relative animate-scaleUp">
            <div className="w-14 h-14 rounded-2xl bg-red-500/20 border border-red-400/50 flex items-center justify-center text-red-400 mx-auto mb-4">
              <ShieldAlert className="w-7 h-7" />
            </div>

            <h3 className="text-xl font-bold font-display text-center text-white mb-2">
              Laporan Rahasia
            </h3>
            <p className="text-xs text-[#D5E9FF]/80 text-center leading-relaxed mb-6">
              Kategori <strong>Keamanan dan Perundungan</strong> merupakan jalur pelaporan sensitif. Laporan kamu akan diisolasi dari publik dan hanya ditangani oleh Guru Bimbingan Konseling (BK) serta petugas safeguarding sekolah yang berwenang. Admin OSIS tidak memiliki akses untuk melihat laporan ini.
            </p>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setShowSecretModalNotice(false);
                  setSelectedCategory('Sarana dan Prasarana');
                }}
                className="w-1/2 py-2.5 rounded-xl text-xs font-semibold text-[#D5E9FF]/70 bg-white/5 hover:bg-white/10 text-center cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={proceedToSecretForm}
                className="w-1/2 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-red-600 to-purple-600 hover:from-red-500 hover:to-purple-500 text-center shadow-lg cursor-pointer"
              >
                Saya Mengerti
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POPUP 2: Confirmation Before Sending (Section 5.2 & Section 6) */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-lg w-full rounded-3xl p-6 sm:p-8 border border-[#36CFFF]/40 animate-scaleUp">
            <h3 className="text-lg font-bold font-display text-white mb-1">
              {formMode === 'secret' ? 'Yakin ingin mengirim laporan ini?' : 'Pratinjau Data Aspirasi'}
            </h3>
            <p className="text-xs text-[#D5E9FF]/60 mb-4">
              Periksa kembali kelengkapan informasi sebelum dikirimkan ke sistem.
            </p>

            {/* Summary preview */}
            <div className="space-y-2.5 text-xs bg-[#080B20]/60 rounded-2xl p-4 border border-white/10 mb-6">
              <div className="flex justify-between">
                <span className="text-[#D5E9FF]/60">Kategori:</span>
                <span className="font-semibold text-[#36CFFF]">{selectedCategory}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#D5E9FF]/60">Identitas:</span>
                <span className="font-semibold text-white">
                  {isAnonymous ? 'Anonim' : `${authorName} (${authorClass})`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#D5E9FF]/60">Judul:</span>
                <span className="font-semibold text-white text-right max-w-xs truncate">{title}</span>
              </div>
              <div className="pt-2 border-t border-white/5">
                <span className="text-[#D5E9FF]/60 block mb-1">Ringkasan Isi:</span>
                <p className="text-[#D5E9FF]/90 italic line-clamp-3 bg-white/5 p-2 rounded-lg text-[11px]">
                  &ldquo;{content}&rdquo;
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-[#D5E9FF]/70 hover:text-white bg-white/5 hover:bg-white/10 cursor-pointer"
              >
                Periksa Kembali
              </button>
              <button
                onClick={handleExecuteSubmit}
                disabled={isSubmitting}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#36CFFF] to-[#876BFF] hover:opacity-90 shadow-lg cursor-pointer disabled:opacity-50"
              >
                {formMode === 'secret' ? 'Ya, Kirim Laporan' : 'Ya, Kirim Aspirasi'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* POPUP 3: Success Modal (Section 5.2 & Section 6) */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-md w-full rounded-3xl p-6 sm:p-8 text-center border border-[#36CFFF]/40 animate-scaleUp">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold font-display text-white mb-2">
              Berhasil Terkirim
            </h3>
            <p className="text-sm text-[#D5E9FF]/90 leading-relaxed mb-6">
              {successMessage}
            </p>

            <button
              onClick={handleFinishSuccess}
              className="w-full glass-button-neon py-3 rounded-xl text-xs font-bold tracking-wider text-white cursor-pointer"
            >
              Kembali ke Dashboard
            </button>
          </div>
        </div>
      )}

      {/* POPUP: Google Drive File Picker Modal */}
      {showDrivePicker && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="w-full max-w-3xl">
            <GoogleDriveExplorer
              isPickerMode={true}
              onClose={() => setShowDrivePicker(false)}
              onSelectDriveFile={(file: DriveFileItem) => {
                setAttachmentPreview(file.thumbnailLink || file.webViewLink || null);
                setDriveAttachedFile(file);
                setShowDrivePicker(false);
              }}
            />
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full border-t border-white/10 py-6 text-center text-xs text-[#D5E9FF]/50 bg-[#080B20]/80">
        © 2026 SMP Negeri 1 Ungaran · Portal Aspirasi Siswa
      </footer>
    </div>
  );
};
