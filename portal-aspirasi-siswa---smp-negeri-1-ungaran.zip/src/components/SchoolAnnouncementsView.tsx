import React, { useState, useEffect, useMemo } from 'react';
import { Announcement } from '../types';
import { StorageService } from '../services/storage';
import { formatWIBDateTime, formatWIBDateOnly } from '../utils/date';
import { ClockWIB } from './ClockWIB';
import {
  ArrowLeft,
  Search,
  Megaphone,
  AlertCircle,
  ExternalLink,
  X,
  Calendar,
  Sparkles,
  UserCheck
} from 'lucide-react';

interface SchoolAnnouncementsViewProps {
  onBackToDashboard: () => void;
}

export const SchoolAnnouncementsView: React.FC<SchoolAnnouncementsViewProps> = ({
  onBackToDashboard
}) => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [visibleCount, setVisibleCount] = useState(6);
  const [activeAnnouncement, setActiveAnnouncement] = useState<Announcement | null>(null);

  useEffect(() => {
    const list = StorageService.getAnnouncements();
    // Sort: Important first (newest to oldest), then normal (newest to oldest) per Section 9
    list.sort((a: Announcement, b: Announcement) => {
      if (a.isImportant && !b.isImportant) return -1;
      if (!a.isImportant && b.isImportant) return 1;
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    });
    setAnnouncements(list);
  }, []);

  // Filter by title only per Section 9
  const filtered = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return announcements;
    return announcements.filter((a) => a.title.toLowerCase().includes(q));
  }, [announcements, searchQuery]);

  const displayed = filtered.slice(0, visibleCount);

  // Close modal via Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveAnnouncement(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between aurora-bg animate-fadeIn">
      {/* Top Navbar */}
      <header className="w-full border-b border-[#36CFFF]/15 bg-[#080B20]/80 backdrop-blur-xl sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToDashboard}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#142B54]/60 hover:bg-[#142B54] border border-[#36CFFF]/30 text-xs text-[#D5E9FF] hover:text-white transition-all cursor-pointer group shadow-sm"
            >
              <ArrowLeft className="w-4 h-4 text-[#36CFFF] group-hover:-translate-x-0.5 transition-transform" />
              <span className="font-medium">Kembali ke Dashboard</span>
            </button>
            <div className="h-4 w-px bg-white/10" />
            <span className="text-xs font-bold text-white tracking-wider uppercase font-display">
              Informasi Sekolah
            </span>
          </div>

          <ClockWIB />
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 flex-1">
        {/* Title & Description */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-4xl font-black font-display text-white mb-2 tracking-tight">
            Informasi & Pengumuman Resmi
          </h1>
          <p className="text-sm text-[#D5E9FF]/70 max-w-2xl">
            Pemberitahuan resmi dari Kepala Sekolah, Wakasek Kesiswaan, Pembina OSIS, dan tim peninjau aspirasi SMP Negeri 1 Ungaran.
          </p>
        </div>

        {/* Search Bar (Title search only per Section 9) */}
        <div className="relative w-full mb-8">
          <Search className="w-5 h-5 text-[#36CFFF] absolute left-4 top-3.5 opacity-70" />
          <input
            type="text"
            placeholder="Cari pengumuman berdasarkan judul..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setVisibleCount(6);
            }}
            className="w-full bg-[#142B54]/50 border border-[#36CFFF]/25 rounded-2xl pl-12 pr-4 py-3 text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#36CFFF] backdrop-blur-md"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-3.5 text-xs text-[#D5E9FF]/50 hover:text-white cursor-pointer"
            >
              Reset
            </button>
          )}
        </div>

        {/* Empty State */}
        {displayed.length === 0 && (
          <div className="py-20 text-center glass-panel rounded-3xl p-8 max-w-lg mx-auto">
            <Megaphone className="w-10 h-10 text-[#36CFFF]/40 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white mb-1">
              Pengumuman tidak ditemukan.
            </h3>
            <p className="text-xs text-[#D5E9FF]/60 mb-4">
              {searchQuery
                ? `Tidak ada pengumuman yang sesuai dengan judul "${searchQuery}".`
                : 'Belum ada pengumuman yang diterbitkan saat ini.'}
            </p>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-[#36CFFF] underline cursor-pointer"
              >
                Hapus pencarian
              </button>
            )}
          </div>
        )}

        {/* Bento Glass Announcement Grid: 2 Col Desktop, 1 Col Mobile per Section 9 */}
        {displayed.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {displayed.map((ann) => (
              <article
                key={ann.id}
                onClick={() => setActiveAnnouncement(ann)}
                className={`group rounded-3xl p-6 glass-panel glass-panel-hover flex flex-col justify-between cursor-pointer relative overflow-hidden transition-all duration-300 ${
                  ann.isImportant
                    ? 'border-[#36CFFF]/60 shadow-[0_0_30px_rgba(54,207,255,0.15)] bg-gradient-to-br from-[#142B54]/60 via-[#142B54]/40 to-[#876BFF]/20'
                    : 'border-white/10'
                }`}
              >
                <div>
                  {/* Top: Priority Label & Publisher */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    {ann.isImportant ? (
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-cyan-200 bg-[#36CFFF]/20 border border-[#36CFFF]/40 px-2.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                        <Sparkles className="w-3 h-3 text-[#36CFFF]" />
                        <span>PENTING / PRIORITAS</span>
                      </span>
                    ) : (
                      <span className="text-xs text-[#D5E9FF]/50 uppercase tracking-wider font-semibold">
                        Pengumuman Sekolah
                      </span>
                    )}

                    <span className="text-[11px] text-[#D5E9FF]/50 font-mono">
                      {formatWIBDateOnly(ann.publishedAt)}
                    </span>
                  </div>

                  {/* Title */}
                  <h2 className="text-lg font-bold font-display text-white group-hover:text-[#36CFFF] transition-colors mb-2.5 leading-snug">
                    {ann.title}
                  </h2>

                  {/* Summary Snippet */}
                  <p className="text-xs text-[#D5E9FF]/75 line-clamp-3 leading-relaxed mb-4">
                    {ann.content}
                  </p>
                </div>

                {/* Footer: Publisher & Link Indicator */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#D5E9FF]/60">
                  <div className="flex items-center gap-1.5 text-xs text-[#36CFFF] font-medium">
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>{ann.publisher}</span>
                  </div>

                  <div className="text-[11px] font-semibold text-white/70 group-hover:text-white flex items-center gap-1">
                    <span>Baca Lengkap</span>
                    <span className="group-hover:translate-x-0.5 transition-transform">→</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* Load More Button (+6 per click) */}
        {filtered.length > visibleCount && (
          <div className="text-center mt-10">
            <button
              onClick={() => setVisibleCount((prev) => prev + 6)}
              className="glass-button-neon px-6 py-3 rounded-2xl text-xs font-bold tracking-wider text-white cursor-pointer"
            >
              Muat Lebih Banyak ({filtered.length - visibleCount} lagi)
            </button>
          </div>
        )}
      </main>

      {/* POPUP Glass Modal: Full Announcement Details (Section 9) */}
      {activeAnnouncement && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="glass-panel w-full max-w-2xl max-h-[92vh] rounded-3xl border border-[#36CFFF]/50 flex flex-col overflow-hidden shadow-2xl relative">
            {/* Header */}
            <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#142B54]/40">
              <div className="flex items-center gap-2">
                {activeAnnouncement.isImportant ? (
                  <span className="text-xs font-bold text-[#36CFFF] bg-[#36CFFF]/20 border border-[#36CFFF]/40 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    PENTING / PRIORITAS
                  </span>
                ) : (
                  <span className="text-xs text-[#D5E9FF]/60 uppercase tracking-wider font-semibold">
                    Pengumuman Resmi
                  </span>
                )}
              </div>

              <button
                onClick={() => setActiveAnnouncement(null)}
                className="p-2 rounded-xl text-[#D5E9FF]/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                title="Tutup (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              <h2 className="text-xl sm:text-2xl font-bold font-display text-white leading-snug">
                {activeAnnouncement.title}
              </h2>

              {/* Publisher & Timestamp Badge */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-[#D5E9FF]/70 pb-4 border-b border-white/10">
                <div className="flex items-center gap-1.5 text-[#36CFFF]">
                  <UserCheck className="w-4 h-4" />
                  <span>Diterbitkan oleh: <strong>{activeAnnouncement.publisher}</strong></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-4 h-4" />
                  <span>{formatWIBDateTime(activeAnnouncement.publishedAt)}</span>
                </div>
              </div>

              {/* Full Text Content */}
              <div className="text-sm text-[#D5E9FF] leading-relaxed whitespace-pre-wrap">
                {activeAnnouncement.content}
              </div>

              {/* Images if available */}
              {activeAnnouncement.images && activeAnnouncement.images.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-[#36CFFF] uppercase tracking-wider">
                    Lampiran Dokumen / Foto
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {activeAnnouncement.images.map((imgUrl, i) => (
                      <div key={i} className="rounded-2xl overflow-hidden border border-white/15">
                        <img src={imgUrl} alt={`Lampiran ${i + 1}`} className="w-full h-44 object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* External Link if provided */}
              {activeAnnouncement.externalLink && (
                <div className="p-4 rounded-2xl bg-[#142B54]/40 border border-[#36CFFF]/30 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-[#D5E9FF]">
                    <ExternalLink className="w-4 h-4 text-[#36CFFF] shrink-0" />
                    <span className="truncate max-w-sm">{activeAnnouncement.externalLink}</span>
                  </div>
                  <a
                    href={activeAnnouncement.externalLink}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-1.5 rounded-xl text-xs font-bold text-white bg-[#36CFFF]/30 hover:bg-[#36CFFF]/50 border border-[#36CFFF] shrink-0 cursor-pointer"
                  >
                    Buka Tautan ↗
                  </a>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-white/10 bg-[#080B20]/90 flex items-center justify-end">
              <button
                onClick={() => setActiveAnnouncement(null)}
                className="px-5 py-2 rounded-xl text-xs font-semibold text-[#D5E9FF] hover:text-white bg-white/10 hover:bg-white/20 cursor-pointer"
              >
                Tutup Pengumuman
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full border-t border-white/10 py-6 text-center text-xs text-[#D5E9FF]/50 bg-[#080B20]/80">
        © 2026 SMP Negeri 1 Ungaran · Portal Aspirasi Siswa
      </footer>
    </div>
  );
};
