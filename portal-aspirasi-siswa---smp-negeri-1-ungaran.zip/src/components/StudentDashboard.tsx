import React from 'react';
import { ClockWIB } from './ClockWIB';
import { Send, FileText, Megaphone, ArrowUpRight, ArrowLeft } from 'lucide-react';

interface StudentDashboardProps {
  onNavigate: (view: 'submit' | 'list' | 'announcements' | 'landing') => void;
  publishedCount: number;
  announcementCount: number;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  onNavigate,
  publishedCount,
  announcementCount
}) => {
  return (
    <div className="min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between aurora-bg animate-fadeIn">
      {/* Top Navbar */}
      <header className="w-full border-b border-[#36CFFF]/15 bg-[#080B20]/70 backdrop-blur-xl sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('landing')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#142B54]/60 hover:bg-[#142B54] border border-[#36CFFF]/30 text-xs text-[#D5E9FF] hover:text-white transition-all cursor-pointer group"
              title="Kembali ke Halaman Gerbang Portal"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-[#36CFFF] group-hover:-translate-x-0.5 transition-transform" />
              <span>Kembali</span>
            </button>

            <div className="h-4 w-px bg-white/10" />

            <div className="flex flex-col">
              <span className="font-display font-bold tracking-widest text-sm sm:text-base text-white">
                SMP NEGERI 1 UNGARAN
              </span>
              <span className="text-[10px] text-[#36CFFF] tracking-wider uppercase font-semibold">
                Portal Aspirasi Siswa
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <ClockWIB />
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-12 flex-1 flex flex-col justify-center">
        {/* Formal Greeting per Section 4 */}
        <div className="mb-10 text-center sm:text-left">
          <div className="inline-block px-3 py-1 mb-2 rounded-full bg-[#142B54]/60 border border-[#36CFFF]/30 text-xs font-semibold text-[#36CFFF] tracking-wider uppercase">
            Spensa Ungaran Digital
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black font-display tracking-tight text-white mb-2">
            Selamat Datang di Portal Aspirasi Siswa.
          </h1>
          <p className="text-sm sm:text-base text-[#D5E9FF]/70 max-w-2xl">
            Sampaikan gagasan, masukan untuk kegiatan sekolah dan fasilitas belajar, pantau tindak lanjut aspirasi, atau baca pengumuman resmi sekolah.
          </p>
        </div>

        {/* Bento Grid: Exactly 3 Main Menus per Section 4 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {/* Card 1: Kirim Aspirasi (Glowing 3D Envelope) */}
          <button
            onClick={() => onNavigate('submit')}
            className="group relative text-left rounded-3xl p-6 sm:p-8 glass-panel glass-panel-hover flex flex-col justify-between overflow-hidden cursor-pointer"
          >
            {/* Glowing cyber accent halo */}
            <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-[#36CFFF]/15 blur-3xl group-hover:bg-[#36CFFF]/30 transition-all duration-500 pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-6">
                {/* 3D Glowing Envelope Icon Container */}
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#142B54] to-[#36CFFF]/30 border border-[#36CFFF]/50 flex items-center justify-center shadow-[0_0_25px_rgba(54,207,255,0.3)] group-hover:scale-110 group-hover:rotate-2 transition-transform duration-300">
                  <Send className="w-8 h-8 text-[#36CFFF] drop-shadow-[0_0_8px_rgba(54,207,255,0.8)]" />
                </div>
                <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[#36CFFF] group-hover:bg-[#36CFFF] group-hover:text-[#080B20] transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>

              <h2 className="text-2xl font-bold font-display text-white mb-2 group-hover:text-[#36CFFF] transition-colors">
                Kirim Aspirasi
              </h2>
              <p className="text-sm text-[#D5E9FF]/70 leading-relaxed mb-6">
                Salurkan ide, usulan sarana prasarana, pembelajaran, atau kegiatan siswa secara beridentitas maupun anonim. Termasuk jalur rahasia keamanan.
              </p>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#36CFFF] font-semibold">
              <span>Formulir Aspirasi Baru</span>
              <span>Mulai Tulis →</span>
            </div>
          </button>

          {/* Card 2: Daftar Aspirasi (Glowing 3D Digital Board) */}
          <button
            onClick={() => onNavigate('list')}
            className="group relative text-left rounded-3xl p-6 sm:p-8 glass-panel glass-panel-hover flex flex-col justify-between overflow-hidden cursor-pointer"
          >
            {/* Glowing violet halo */}
            <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-[#876BFF]/15 blur-3xl group-hover:bg-[#876BFF]/30 transition-all duration-500 pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-6">
                {/* 3D Digital Board Icon Container */}
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#142B54] to-[#876BFF]/30 border border-[#876BFF]/50 flex items-center justify-center shadow-[0_0_25px_rgba(135,107,255,0.3)] group-hover:scale-110 group-hover:-rotate-2 transition-transform duration-300">
                  <FileText className="w-8 h-8 text-[#876BFF] drop-shadow-[0_0_8px_rgba(135,107,255,0.8)]" />
                </div>
                <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[#876BFF] group-hover:bg-[#876BFF] group-hover:text-white transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>

              <h2 className="text-2xl font-bold font-display text-white mb-2 group-hover:text-[#876BFF] transition-colors">
                Daftar Aspirasi
              </h2>
              <p className="text-sm text-[#D5E9FF]/70 leading-relaxed mb-6">
                Lihat kumpulan aspirasi umum yang telah ditinjau dan diterbitkan oleh Admin OSIS. Dukung dengan Like dan berikan tanggapan.
              </p>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#876BFF] font-semibold">
              <span>{publishedCount} Aspirasi Terbit</span>
              <span>Buka Galeri →</span>
            </div>
          </button>

          {/* Card 3: Informasi Sekolah (Glowing 3D Megaphone) */}
          <button
            onClick={() => onNavigate('announcements')}
            className="group relative text-left rounded-3xl p-6 sm:p-8 glass-panel glass-panel-hover flex flex-col justify-between overflow-hidden cursor-pointer"
          >
            {/* Glowing cyan/blue halo */}
            <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-[#36CFFF]/15 blur-3xl group-hover:bg-[#36CFFF]/30 transition-all duration-500 pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-6">
                {/* 3D Megaphone Icon Container */}
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#142B54] to-[#36CFFF]/30 border border-[#36CFFF]/50 flex items-center justify-center shadow-[0_0_25px_rgba(54,207,255,0.3)] group-hover:scale-110 group-hover:rotate-2 transition-transform duration-300">
                  <Megaphone className="w-8 h-8 text-[#36CFFF] drop-shadow-[0_0_8px_rgba(54,207,255,0.8)]" />
                </div>
                <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[#36CFFF] group-hover:bg-[#36CFFF] group-hover:text-[#080B20] transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
              </div>

              <h2 className="text-2xl font-bold font-display text-white mb-2 group-hover:text-[#36CFFF] transition-colors">
                Informasi Sekolah
              </h2>
              <p className="text-sm text-[#D5E9FF]/70 leading-relaxed mb-6">
                Pengumuman resmi dari Kepala Sekolah, Wakasek Kesiswaan, Pembina OSIS, dan tim peninjau aspirasi SMP Negeri 1 Ungaran.
              </p>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#36CFFF] font-semibold">
              <span>{announcementCount} Pengumuman Terbit</span>
              <span>Baca Info →</span>
            </div>
          </button>
        </div>

        {/* Portal Information Card */}
        <div className="mt-10 rounded-2xl p-5 bg-[#142B54]/30 border border-[#36CFFF]/20 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-[#36CFFF] animate-pulse shrink-0" />
            <p className="text-xs text-[#D5E9FF]/80">
              <strong className="text-white">Transparansi Aspirasi:</strong> Setiap aspirasi umum yang masuk ditinjau secara berkala oleh Admin OSIS dan diteruskan ke pihak sekolah untuk tindak lanjut nyata.
            </p>
          </div>
          <button
            onClick={() => onNavigate('list')}
            className="text-xs text-[#36CFFF] hover:text-white font-semibold underline underline-offset-4 shrink-0 cursor-pointer"
          >
            Lihat Aspirasi yang Ditindaklanjuti
          </button>
        </div>
      </main>

      {/* Footer per Section 4 */}
      <footer className="w-full border-t border-white/10 py-6 text-center text-xs text-[#D5E9FF]/50 bg-[#080B20]/80">
        © 2026 SMP Negeri 1 Ungaran · Portal Aspirasi Siswa
      </footer>
    </div>
  );
};
