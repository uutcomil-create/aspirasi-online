import React, { useState, useEffect } from 'react';
import { StorageService } from '../services/storage';
import {
  Lock,
  KeyRound,
  ArrowLeft,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  ShieldCheck
} from 'lucide-react';

interface AdminLoginProps {
  onLoginSuccess: () => void;
  onBackToPortal: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({
  onLoginSuccess,
  onBackToPortal
}) => {
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);
  const [lockCountdown, setLockCountdown] = useState<number>(0);

  // Recovery modal
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [recoveryCodeInput, setRecoveryCodeInput] = useState('');
  const [recoveryNewPassword, setRecoveryNewPassword] = useState('');
  const [recoveryError, setRecoveryError] = useState<string | null>(null);
  const [recoverySuccess, setRecoverySuccess] = useState(false);

  useEffect(() => {
    const config = StorageService.getAdminConfig();
    setFailedAttempts(config.failedAttempts || 0);
    setLockedUntil(config.lockedUntil);
  }, []);

  // Countdown timer for 15-minute lock
  useEffect(() => {
    if (!lockedUntil) return;
    const interval = setInterval(() => {
      const remainingMs = lockedUntil - Date.now();
      if (remainingMs <= 0) {
        setLockedUntil(null);
        setLockCountdown(0);
        // Reset failed attempts in storage
        const cfg = StorageService.getAdminConfig();
        cfg.failedAttempts = 0;
        cfg.lockedUntil = null;
        StorageService.saveAdminConfig(cfg);
        setFailedAttempts(0);
      } else {
        setLockCountdown(Math.ceil(remainingMs / 1000));
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [lockedUntil]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (lockedUntil && Date.now() < lockedUntil) {
      setErrorMsg(`Akun terkunci sementara karena 5x percobaan gagal. Tunggu ${Math.ceil(lockCountdown / 60)} menit lagi.`);
      return;
    }

    const config = StorageService.getAdminConfig();

    if (password === config.passwordHash || (password === 'admin123' && !config.passwordHash)) {
      // Success
      config.failedAttempts = 0;
      config.lockedUntil = null;
      StorageService.saveAdminConfig(config);
      StorageService.recordLoginAttempt(true);
      onLoginSuccess();
    } else {
      // Failure
      const newAttempts = (config.failedAttempts || 0) + 1;
      config.failedAttempts = newAttempts;
      StorageService.recordLoginAttempt(false);

      if (newAttempts >= 5) {
        const lockDuration = 15 * 60 * 1000; // 15 mins lock per Section 11
        const until = Date.now() + lockDuration;
        config.lockedUntil = until;
        setLockedUntil(until);
        setLockCountdown(15 * 60);
        setErrorMsg('Maksimal 5x percobaan gagal. Akun dikunci sementara selama 15 menit.');
      } else {
        setErrorMsg(`Password salah! Tersisa ${5 - newAttempts} percobaan lagi sebelum akun dikunci 15 menit.`);
      }
      setFailedAttempts(newAttempts);
      StorageService.saveAdminConfig(config);
    }
  };

  const handleRecoverySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    const config = StorageService.getAdminConfig();
    const cleanCode = recoveryCodeInput.trim();

    if (cleanCode !== config.recoveryCode) {
      setRecoveryError('Kode pemulihan tidak valid.');
      return;
    }
    if (recoveryNewPassword.length < 6) {
      setRecoveryError('Password baru minimal 6 karakter.');
      return;
    }

    // Reset password & unlock
    config.passwordHash = recoveryNewPassword;
    config.failedAttempts = 0;
    config.lockedUntil = null;
    StorageService.saveAdminConfig(config);
    setLockedUntil(null);
    setFailedAttempts(0);
    setRecoverySuccess(true);
  };

  return (
    <div className="min-h-screen w-full bg-[#080B20] text-[#D5E9FF] flex flex-col justify-between items-center p-4 aurora-bg">
      {/* Top back button */}
      <div className="w-full max-w-md pt-6 flex justify-start">
        <button
          onClick={onBackToPortal}
          className="flex items-center gap-2 text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 hover:bg-white/10 px-3.5 py-1.5 rounded-xl border border-white/10 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-[#36CFFF]" />
          <span>Kembali ke Portal</span>
        </button>
      </div>

      {/* Main Login Box */}
      <div className="w-full max-w-md glass-panel rounded-3xl p-6 sm:p-8 border border-[#36CFFF]/40 shadow-2xl relative my-auto">
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#142B54] to-[#36CFFF]/30 border border-[#36CFFF]/50 flex items-center justify-center text-[#36CFFF] mx-auto mb-3 shadow-[0_0_20px_rgba(54,207,255,0.3)]">
            <Lock className="w-7 h-7" />
          </div>
          <span className="text-[10px] uppercase font-bold tracking-widest text-[#36CFFF]">
            SMP NEGERI 1 UNGARAN
          </span>
          <h1 className="text-2xl font-black font-display text-white mt-1">
            Login Admin OSIS
          </h1>
          <p className="text-xs text-[#D5E9FF]/60 mt-1">
            Masuk untuk meninjau aspirasi umum & mengelola pengumuman
          </p>
        </div>

        {/* Lockout Warning */}
        {lockedUntil && (
          <div className="mb-4 p-3.5 rounded-2xl bg-red-950/40 border border-red-500/50 text-red-200 text-xs flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
            <div>
              <strong className="block">Akun Terkunci Sementara (15 Menit)</strong>
              <span>Tersisa waktu: {Math.floor(lockCountdown / 60)}m {lockCountdown % 60}s</span>
            </div>
          </div>
        )}

        {/* Error message */}
        {errorMsg && !lockedUntil && (
          <div className="mb-4 p-3 rounded-xl bg-red-900/30 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#D5E9FF]/80 mb-1.5">
              Akun Administrator
            </label>
            <input
              type="text"
              value="Admin Utama OSIS"
              disabled
              className="w-full bg-[#142B54]/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white/60 cursor-not-allowed"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-semibold text-[#36CFFF]">
                Password Admin
              </label>
              <button
                type="button"
                onClick={() => {
                  setShowRecoveryModal(true);
                  setRecoverySuccess(false);
                  setRecoveryError(null);
                }}
                className="text-[11px] text-[#D5E9FF]/60 hover:text-[#36CFFF] underline cursor-pointer"
              >
                Gunakan Kode Pemulihan
              </button>
            </div>
            <div className="relative">
              <input
                type="password"
                placeholder="Masukkan password admin..."
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={Boolean(lockedUntil)}
                className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl pl-4 pr-10 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#36CFFF]"
              />
              <KeyRound className="w-4 h-4 text-[#36CFFF] absolute right-3.5 top-3.5 opacity-60" />
            </div>
          </div>

          <button
            type="submit"
            disabled={Boolean(lockedUntil)}
            className="w-full glass-button-neon py-3 rounded-xl text-xs font-bold tracking-wider text-white cursor-pointer disabled:opacity-40"
          >
            Masuk ke Dashboard Admin
          </button>
        </form>

        {/* Quick Demo helper badge */}
        <div className="mt-6 p-3 rounded-xl bg-white/5 border border-white/10 text-[11px] text-[#D5E9FF]/60 text-center space-y-0.5">
          <div>Kredensial Default Sekolah:</div>
          <div>Password: <code className="text-[#36CFFF] font-bold">admin123</code> · Kode Pemulihan: <code className="text-[#876BFF] font-bold">UNGARAN-RECOVER-2026</code></div>
        </div>
      </div>

      {/* POPUP: Recovery Code Reset Modal (Section 11) */}
      {showRecoveryModal && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-md w-full rounded-3xl p-6 sm:p-8 border border-[#876BFF]/50 animate-scaleUp">
            <div className="text-center mb-4">
              <div className="w-12 h-12 rounded-2xl bg-[#876BFF]/20 border border-[#876BFF]/40 text-[#876BFF] flex items-center justify-center mx-auto mb-2">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold font-display text-white">
                Pemulihan Akun Admin
              </h3>
              <p className="text-xs text-[#D5E9FF]/60">
                Gunakan kode pemulihan resmi untuk membuka kunci dan mengatur ulang password.
              </p>
            </div>

            {recoverySuccess ? (
              <div className="text-center space-y-4 py-4">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <p className="text-xs text-emerald-200">
                  Password berhasil diatur ulang! Silakan masuk dengan password baru kamu.
                </p>
                <button
                  onClick={() => setShowRecoveryModal(false)}
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-[#36CFFF] text-[#080B20] cursor-pointer"
                >
                  Tutup & Lanjutkan Login
                </button>
              </div>
            ) : (
              <form onSubmit={handleRecoverySubmit} className="space-y-4">
                {recoveryError && (
                  <div className="p-3 rounded-xl bg-red-900/30 border border-red-500/40 text-red-200 text-xs">
                    {recoveryError}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-[#D5E9FF]/80 mb-1">
                    Masukkan Kode Pemulihan
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: UNGARAN-RECOVER-2026"
                    value={recoveryCodeInput}
                    onChange={(e) => setRecoveryCodeInput(e.target.value)}
                    className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3.5 py-2.5 text-xs text-white uppercase focus:outline-none focus:border-[#876BFF]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#D5E9FF]/80 mb-1">
                    Password Baru (min. 6 karakter)
                  </label>
                  <input
                    type="password"
                    placeholder="Masukkan password baru..."
                    value={recoveryNewPassword}
                    onChange={(e) => setRecoveryNewPassword(e.target.value)}
                    className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#876BFF]"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowRecoveryModal(false)}
                    className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#876BFF] to-[#36CFFF] cursor-pointer"
                  >
                    Reset & Buka Kunci
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full py-4 text-center text-xs text-[#D5E9FF]/40">
        © 2026 SMP Negeri 1 Ungaran · Portal Aspirasi Siswa
      </footer>
    </div>
  );
};
