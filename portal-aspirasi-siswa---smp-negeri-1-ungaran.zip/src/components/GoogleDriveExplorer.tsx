import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  logoutGoogle,
  getAccessToken
} from '../services/googleDriveAuth';
import {
  GoogleDriveService,
  DriveFileItem,
  DriveAboutInfo
} from '../services/googleDriveApi';
import {
  HardDrive,
  FolderPlus,
  Upload,
  Search,
  RefreshCw,
  Trash2,
  ExternalLink,
  FileText,
  Folder,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  LogOut,
  X,
  FileSpreadsheet,
  FileCheck
} from 'lucide-react';

interface GoogleDriveExplorerProps {
  onSelectDriveFile?: (file: DriveFileItem) => void;
  isPickerMode?: boolean;
  onClose?: () => void;
}

export const GoogleDriveExplorer: React.FC<GoogleDriveExplorerProps> = ({
  onSelectDriveFile,
  isPickerMode = false,
  onClose
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Drive state
  const [aboutInfo, setAboutInfo] = useState<DriveAboutInfo | null>(null);
  const [files, setFiles] = useState<DriveFileItem[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentFolderId, setCurrentFolderId] = useState<string | undefined>(undefined);
  const [folderHistory, setFolderHistory] = useState<{ id?: string; name: string }[]>([
    { id: undefined, name: 'Drive Saya' }
  ]);

  // Upload state
  const [isUploading, setIsUploading] = useState(false);
  const [uploadToast, setUploadToast] = useState<string | null>(null);

  // Create folder modal
  const [showFolderModal, setShowFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  // Destructive delete confirmation modal (MANDATORY per workspace skill)
  const [fileToDelete, setFileToDelete] = useState<DriveFileItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const unsubscribe = initAuth(
      (authedUser, userToken) => {
        setUser(authedUser);
        setToken(userToken);
        setNeedsAuth(false);
      },
      () => {
        setUser(null);
        setToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (token) {
      loadDriveData();
    }
  }, [token, currentFolderId]);

  const loadDriveData = async () => {
    setIsLoadingFiles(true);
    setAuthError(null);
    try {
      const [about, fileList] = await Promise.all([
        GoogleDriveService.getAboutInfo().catch(() => null),
        GoogleDriveService.listFiles(searchQuery, currentFolderId)
      ]);
      if (about) setAboutInfo(about);
      setFiles(fileList);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal memuat data dari Google Drive.';
      setAuthError(msg);
    } finally {
      setIsLoadingFiles(false);
    }
  };

  const handleSignIn = async () => {
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setToken(result.accessToken);
        setNeedsAuth(false);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal melakukan login Google.';
      setAuthError(msg);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignOut = async () => {
    await logoutGoogle();
    setUser(null);
    setToken(null);
    setAboutInfo(null);
    setFiles([]);
    setNeedsAuth(true);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadDriveData();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setAuthError(null);
    try {
      const uploaded = await GoogleDriveService.uploadFile(file, currentFolderId);
      setUploadToast(`Berkas "${uploaded.name}" berhasil diunggah ke Google Drive!`);
      setTimeout(() => setUploadToast(null), 3500);
      loadDriveData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal mengunggah berkas ke Google Drive.';
      setAuthError(msg);
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;

    try {
      await GoogleDriveService.createFolder(newFolderName.trim(), currentFolderId);
      setNewFolderName('');
      setShowFolderModal(false);
      setUploadToast('Folder baru berhasil dibuat di Google Drive!');
      setTimeout(() => setUploadToast(null), 3000);
      loadDriveData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal membuat folder.';
      setAuthError(msg);
    }
  };

  // Execute Destructive Delete after user confirmation
  const handleConfirmDelete = async () => {
    if (!fileToDelete) return;
    setIsDeleting(true);
    try {
      await GoogleDriveService.deleteFile(fileToDelete.id);
      setUploadToast(`Berkas "${fileToDelete.name}" telah dihapus dari Google Drive.`);
      setTimeout(() => setUploadToast(null), 3000);
      setFileToDelete(null);
      loadDriveData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal menghapus berkas.';
      setAuthError(msg);
    } finally {
      setIsDeleting(false);
    }
  };

  const formatFileSize = (bytesStr?: string) => {
    if (!bytesStr) return '-';
    const bytes = parseInt(bytesStr, 10);
    if (isNaN(bytes)) return '-';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const renderFileIcon = (mimeType: string) => {
    if (mimeType.includes('folder')) return <Folder className="w-5 h-5 text-amber-400 shrink-0" />;
    if (mimeType.includes('image')) return <ImageIcon className="w-5 h-5 text-[#36CFFF] shrink-0" />;
    if (mimeType.includes('spreadsheet') || mimeType.includes('sheet'))
      return <FileSpreadsheet className="w-5 h-5 text-emerald-400 shrink-0" />;
    return <FileText className="w-5 h-5 text-[#876BFF] shrink-0" />;
  };

  return (
    <div className="glass-panel w-full rounded-3xl border border-[#36CFFF]/30 overflow-hidden shadow-2xl relative">
      {/* Header */}
      <div className="p-5 border-b border-white/10 bg-[#142B54]/40 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#142B54] to-[#36CFFF]/30 border border-[#36CFFF]/40 flex items-center justify-center text-[#36CFFF] shadow-md">
            <HardDrive className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold font-display text-white">
                Google Drive Sekolah
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#36CFFF]/20 border border-[#36CFFF]/40 text-[#36CFFF] font-semibold">
                Integrasi Resmi
              </span>
            </div>
            <p className="text-xs text-[#D5E9FF]/60">
              Penyimpanan berkas lampiran, foto kegiatan, dan arsip dokumen SMP Negeri 1 Ungaran
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-[#D5E9FF]/70 hover:text-white hover:bg-white/10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Toast Notice */}
      {uploadToast && (
        <div className="mx-5 mt-4 p-3 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 text-xs flex items-center gap-2 animate-scaleUp">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{uploadToast}</span>
        </div>
      )}

      {/* Error Banner */}
      {authError && (
        <div className="mx-5 mt-4 p-3 rounded-2xl bg-red-950/40 border border-red-500/50 text-red-200 text-xs flex items-center gap-2 animate-scaleUp">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{authError}</span>
        </div>
      )}

      {/* Auth Gate: Sign in with Google (Styled to official Google Sign-in specification) */}
      {needsAuth || !user ? (
        <div className="p-8 sm:p-12 text-center max-w-md mx-auto space-y-5">
          <div className="w-16 h-16 rounded-3xl bg-[#142B54]/60 border border-[#36CFFF]/30 flex items-center justify-center mx-auto text-[#36CFFF] shadow-lg">
            <HardDrive className="w-8 h-8 animate-pulse" />
          </div>

          <div>
            <h3 className="text-lg font-bold font-display text-white">
              Hubungkan ke Google Drive
            </h3>
            <p className="text-xs text-[#D5E9FF]/70 mt-1 leading-relaxed">
              Masuk dengan akun Google sekolah untuk mengakses folder berkas, mengunggah lampiran aspirasi, atau menyematkan dokumen resmi.
            </p>
          </div>

          {/* Official Styled "Sign in with Google" Button */}
          <div className="flex justify-center pt-2">
            <button
              onClick={handleSignIn}
              disabled={isLoggingIn}
              className="group relative flex items-center gap-3 px-6 py-3 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs transition-all shadow-md hover:shadow-lg cursor-pointer border border-slate-200 disabled:opacity-50"
            >
              {isLoggingIn ? (
                <div className="w-4 h-4 border-2 border-slate-400 border-t-blue-600 rounded-full animate-spin" />
              ) : (
                <svg className="w-4 h-4" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
              )}
              <span>{isLoggingIn ? 'Menghubungkan...' : 'Sign in with Google'}</span>
            </button>
          </div>

          <p className="text-[11px] text-[#D5E9FF]/50">
            Aplikasi meminta izin baca & kelola berkas Google Drive dengan izin pengguna.
          </p>
        </div>
      ) : (
        // Authenticated Google Drive View
        <div className="p-5 sm:p-6 space-y-5 animate-fadeIn">
          {/* User Profile Bar & Storage Quota */}
          <div className="p-4 rounded-2xl bg-[#080B20]/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'Google User'}
                  className="w-10 h-10 rounded-full border border-[#36CFFF]/40 object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-[#142B54] border border-[#36CFFF]/40 flex items-center justify-center font-bold text-[#36CFFF]">
                  {user.displayName?.[0] || 'U'}
                </div>
              )}
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <span>{user.displayName || 'Akun Google Sekolah'}</span>
                  <span className="text-[10px] text-emerald-400 font-normal">● Terhubung</span>
                </div>
                <div className="text-[11px] text-[#D5E9FF]/60">{user.email}</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={loadDriveData}
                disabled={isLoadingFiles}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#36CFFF] border border-white/10 cursor-pointer"
                title="Muat Ulang Berkas"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingFiles ? 'animate-spin' : ''}`} />
              </button>

              <button
                onClick={handleSignOut}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600/10 hover:bg-red-600/20 text-red-300 border border-red-500/30 text-xs font-semibold cursor-pointer"
                title="Keluar dari akun Google"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Putuskan</span>
              </button>
            </div>
          </div>

          {/* Action Toolbar: Search, Upload, New Folder */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Search form */}
            <form onSubmit={handleSearch} className="w-full sm:w-72 relative">
              <Search className="w-4 h-4 text-[#36CFFF] absolute left-3.5 top-2.5 opacity-60" />
              <input
                type="text"
                placeholder="Cari berkas di Drive..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#142B54]/70 border border-white/20 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#36CFFF]"
              />
            </form>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              {/* New Folder Button */}
              <button
                onClick={() => setShowFolderModal(true)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 text-xs font-semibold text-[#D5E9FF] hover:text-white cursor-pointer"
              >
                <FolderPlus className="w-3.5 h-3.5 text-amber-400" />
                <span>Folder Baru</span>
              </button>

              {/* Upload File to Drive */}
              <label
                className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl glass-button-neon text-xs font-bold text-white cursor-pointer ${
                  isUploading ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <Upload className="w-3.5 h-3.5 text-[#36CFFF]" />
                <span>{isUploading ? 'Mengunggah...' : 'Unggah Berkas'}</span>
                <input
                  type="file"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Folder Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs text-[#D5E9FF]/70 pb-2 border-b border-white/10">
            {folderHistory.map((item, idx) => (
              <React.Fragment key={idx}>
                {idx > 0 && <span className="text-white/30">/</span>}
                <button
                  onClick={() => {
                    setCurrentFolderId(item.id);
                    setFolderHistory((prev) => prev.slice(0, idx + 1));
                  }}
                  className={`hover:text-[#36CFFF] transition-colors cursor-pointer ${
                    idx === folderHistory.length - 1 ? 'font-bold text-white' : ''
                  }`}
                >
                  {item.name}
                </button>
              </React.Fragment>
            ))}
          </div>

          {/* Files List Table */}
          <div className="rounded-2xl border border-white/10 bg-[#080B20]/40 overflow-hidden">
            {isLoadingFiles ? (
              <div className="p-12 text-center text-xs text-[#36CFFF] flex items-center justify-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Memuat berkas Google Drive...</span>
              </div>
            ) : files.length === 0 ? (
              <div className="p-12 text-center text-xs text-[#D5E9FF]/50 space-y-2">
                <HardDrive className="w-8 h-8 mx-auto opacity-30" />
                <p>Tidak ada berkas yang ditemukan dalam folder ini.</p>
              </div>
            ) : (
              <div className="divide-y divide-white/5">
                {files.map((file) => {
                  const isFolder = file.mimeType.includes('folder');
                  return (
                    <div
                      key={file.id}
                      className="p-3.5 hover:bg-[#142B54]/40 flex items-center justify-between gap-3 transition-colors text-xs"
                    >
                      <div
                        onClick={() => {
                          if (isFolder) {
                            setCurrentFolderId(file.id);
                            setFolderHistory((prev) => [...prev, { id: file.id, name: file.name }]);
                          } else if (onSelectDriveFile) {
                            onSelectDriveFile(file);
                          }
                        }}
                        className={`flex items-center gap-3 flex-1 min-w-0 ${
                          isFolder || onSelectDriveFile ? 'cursor-pointer' : ''
                        }`}
                      >
                        {renderFileIcon(file.mimeType)}
                        <div className="truncate">
                          <div className="font-semibold text-white truncate hover:text-[#36CFFF]">
                            {file.name}
                          </div>
                          <div className="text-[10px] text-[#D5E9FF]/50">
                            {formatFileSize(file.size)}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {/* Select in picker mode */}
                        {isPickerMode && onSelectDriveFile && !isFolder && (
                          <button
                            onClick={() => onSelectDriveFile(file)}
                            className="flex items-center gap-1 px-3 py-1 rounded-lg bg-[#36CFFF]/20 text-[#36CFFF] hover:bg-[#36CFFF]/30 text-xs font-semibold cursor-pointer"
                          >
                            <FileCheck className="w-3.5 h-3.5" />
                            <span>Pilih</span>
                          </button>
                        )}

                        {/* Open in Drive link */}
                        {file.webViewLink && (
                          <a
                            href={file.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 rounded-lg hover:bg-white/10 text-[#D5E9FF]/70 hover:text-white cursor-pointer"
                            title="Buka di Google Drive"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {/* Delete Button (Triggers mandatory confirmation modal) */}
                        <button
                          onClick={() => setFileToDelete(file)}
                          className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 hover:text-red-300 cursor-pointer"
                          title="Hapus berkas dari Google Drive"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* POPUP: Create Folder Modal */}
      {showFolderModal && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-sm w-full rounded-3xl p-6 border border-[#36CFFF]/40 animate-scaleUp">
            <h3 className="text-base font-bold font-display text-white mb-2">
              Buat Folder Baru di Google Drive
            </h3>
            <form onSubmit={handleCreateFolder} className="space-y-4">
              <div>
                <input
                  type="text"
                  placeholder="Nama folder (misal: Dokumen OSIS 2026)..."
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  autoFocus
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#36CFFF]"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowFolderModal(false)}
                  className="px-3.5 py-1.5 rounded-xl text-xs text-[#D5E9FF]/70 hover:text-white bg-white/5 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="glass-button-neon px-4 py-1.5 rounded-xl text-xs font-bold text-white cursor-pointer"
                >
                  Buat Folder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* POPUP: Mandatory Confirmation for Destructive Operations */}
      {fileToDelete && (
        <div className="fixed inset-0 z-50 bg-[#080B20]/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="glass-panel max-w-md w-full rounded-3xl p-6 border border-red-500/50 animate-scaleUp space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-red-950/60 border border-red-500/40 text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-base font-bold font-display text-white">
                Hapus Berkas dari Google Drive?
              </h3>
              <p className="text-xs text-[#D5E9FF]/70 mt-1 leading-relaxed">
                Tindakan ini akan menghapus berkas <strong className="text-white">&ldquo;{fileToDelete.name}&rdquo;</strong> dari Google Drive Anda. Tindakan ini tidak dapat dibatalkan.
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setFileToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl text-xs text-[#D5E9FF]/80 hover:text-white bg-white/5 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 shadow-lg cursor-pointer disabled:opacity-50"
              >
                {isDeleting ? 'Menghapus...' : 'Ya, Hapus Berkas'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
