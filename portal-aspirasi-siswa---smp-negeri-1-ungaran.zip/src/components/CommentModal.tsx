import React, { useState, useEffect } from 'react';
import { Comment, Aspiration } from '../types';
import { StorageService } from '../services/storage';
import { formatWIBDateTime } from '../utils/date';
import {
  X,
  MessageSquare,
  Send,
  AlertCircle,
  CheckCircle2,
  UserCheck
} from 'lucide-react';

interface CommentModalProps {
  aspiration: Aspiration;
  deviceId: string;
  onClose: () => void;
  onCommentAdded: () => void;
}

export const CommentModal: React.FC<CommentModalProps> = ({
  aspiration,
  deviceId,
  onClose,
  onCommentAdded
}) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [visibleCount, setVisibleCount] = useState<number>(10);

  // Nickname saved in localStorage
  const [nickname, setNickname] = useState<string>(() => {
    return localStorage.getItem('smpn1_user_nickname') || '';
  });

  const [commentText, setCommentText] = useState<string>('');
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Device comment count for this aspiration (max 3)
  const [deviceCommentCount, setDeviceCommentCount] = useState<number>(0);

  const loadComments = () => {
    const list = StorageService.getComments(aspiration.id);
    setComments(list);
    setDeviceCommentCount(StorageService.getDeviceCommentCount(aspiration.id, deviceId));
  };

  useEffect(() => {
    loadComments();
  }, [aspiration.id, deviceId]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const trimmedNick = nickname.trim();
    const trimmedText = commentText.trim();

    if (!trimmedNick) {
      setErrorMsg('Silakan tentukan nama samaran / nickname kamu.');
      return;
    }
    if (trimmedText.length < 1 || trimmedText.length > 500) {
      setErrorMsg('Komentar harus berisi antara 1 hingga 500 karakter.');
      return;
    }

    try {
      // Save nickname to browser
      localStorage.setItem('smpn1_user_nickname', trimmedNick);

      StorageService.addComment(aspiration.id, trimmedNick, trimmedText, deviceId);
      setCommentText('');
      setIsFormOpen(false);

      // Reload
      loadComments();
      onCommentAdded();

      // Show toast for 3s per Section 8
      setToastMsg('Komentar berhasil dikirim!');
      setTimeout(() => {
        setToastMsg(null);
      }, 3000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal mengirim komentar.';
      setErrorMsg(msg);
    }
  };

  const displayedComments = comments.slice(0, visibleCount);

  return (
    <div className="fixed inset-0 z-50 bg-[#080B20]/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      {/* Container: click outside does NOT close per spec */}
      <div className="glass-panel w-full max-w-2xl max-h-[90vh] rounded-3xl border border-[#36CFFF]/40 flex flex-col overflow-hidden shadow-2xl relative">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-[#142B54]/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#36CFFF]/20 border border-[#36CFFF]/40 flex items-center justify-center text-[#36CFFF]">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-white">
                Ruang Tanggapan & Komentar
              </h3>
              <p className="text-xs text-[#D5E9FF]/60 truncate max-w-sm sm:max-w-md">
                {aspiration.title}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#D5E9FF]/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Tutup (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3-Second Toast per Section 8 */}
        {toastMsg && (
          <div className="mx-5 mt-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-xs flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* Error notice */}
        {errorMsg && (
          <div className="mx-5 mt-4 p-3 rounded-xl bg-red-900/30 border border-red-500/40 text-red-200 text-xs flex items-center gap-2 animate-fadeIn">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Comment List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3.5">
          {comments.length === 0 ? (
            <div className="py-12 text-center text-xs text-[#D5E9FF]/50">
              Belum ada komentar pada aspirasi ini. Jadilah yang pertama memberikan masukan!
            </div>
          ) : (
            displayedComments.map((com) => (
              <div
                key={com.id}
                className="p-4 rounded-2xl bg-[#080B20]/50 border border-white/10 space-y-1.5"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#36CFFF]">{com.nickname}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-[#D5E9FF]/50">
                      Siswa
                    </span>
                  </div>
                  <span className="text-[11px] text-[#D5E9FF]/40 font-mono">
                    {formatWIBDateTime(com.createdAt)}
                  </span>
                </div>
                <p className="text-xs text-[#D5E9FF]/90 leading-relaxed break-words">
                  {com.content}
                </p>
              </div>
            ))
          )}

          {/* Load More Comments button if > 10 */}
          {comments.length > visibleCount && (
            <div className="text-center pt-2">
              <button
                onClick={() => setVisibleCount((prev) => prev + 10)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-[#36CFFF] bg-[#142B54]/40 hover:bg-[#142B54] border border-[#36CFFF]/30 cursor-pointer"
              >
                Muat 10 Komentar Berikutnya
              </button>
            </div>
          )}
        </div>

        {/* Bottom Form or "Tambah Komentar" Toggle */}
        <div className="p-4 border-t border-white/10 bg-[#080B20]/90">
          {deviceCommentCount >= 3 ? (
            <div className="text-center py-2 text-xs text-[#D5E9FF]/60 bg-white/5 rounded-xl border border-white/10">
              Kamu telah mencapai batas maksimal 3 komentar untuk aspirasi ini pada perangkat ini.
            </div>
          ) : isFormOpen ? (
            <form onSubmit={handleSubmit} className="space-y-3 animate-fadeIn">
              <div className="flex flex-col sm:flex-row items-center gap-2">
                <div className="relative w-full sm:w-1/2">
                  <input
                    type="text"
                    placeholder="Nama Samaran / Nickname kamu..."
                    value={nickname}
                    onChange={(e) => setNickname(e.target.value)}
                    maxLength={30}
                    className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#36CFFF]"
                  />
                  <UserCheck className="w-4 h-4 text-[#36CFFF] absolute right-3 top-2.5 opacity-60" />
                </div>
                <div className="w-full sm:w-1/2 text-[11px] text-[#D5E9FF]/50 text-right">
                  Tersisa {3 - deviceCommentCount} kuota komentar
                </div>
              </div>

              <div className="relative">
                <textarea
                  rows={3}
                  placeholder="Tulis tanggapan atau saran konstruktif (maks. 500 karakter)..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  maxLength={500}
                  className="w-full bg-[#142B54]/80 border border-white/20 rounded-xl p-3 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#36CFFF] resize-none"
                />
                <span className="absolute bottom-2 right-3 text-[10px] text-[#D5E9FF]/40 font-mono">
                  {commentText.length}/500
                </span>
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-3.5 py-1.5 rounded-xl text-xs text-[#D5E9FF]/60 hover:text-white bg-white/5 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="glass-button-neon px-4 py-1.5 rounded-xl text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5 text-[#36CFFF]" />
                  <span>Kirim Komentar</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#D5E9FF]/60">
                Sisa kuota tanggapan: <strong className="text-white">{3 - deviceCommentCount}</strong>/3
              </span>
              <button
                onClick={() => setIsFormOpen(true)}
                className="glass-button-neon px-4 py-2 rounded-xl text-xs font-semibold text-white flex items-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#36CFFF]" />
                <span>Tambah Komentar</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
