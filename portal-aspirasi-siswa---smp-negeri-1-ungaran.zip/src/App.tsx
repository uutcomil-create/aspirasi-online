/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { LandingPage } from './components/LandingPage';
import { StudentDashboard } from './components/StudentDashboard';
import { SubmitAspirationView } from './components/SubmitAspirationView';
import { AspirationListView } from './components/AspirationListView';
import { SchoolAnnouncementsView } from './components/SchoolAnnouncementsView';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';
import { SafeguardingPortal } from './components/SafeguardingPortal';
import { StorageService } from './services/storage';

export type AppView =
  | 'landing'
  | 'student_dashboard'
  | 'submit_aspiration'
  | 'aspiration_list'
  | 'school_announcements'
  | 'admin_login'
  | 'admin_dashboard'
  | 'safeguarding';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [deviceId, setDeviceId] = useState<string>('spensa_dev_default');

  // Stats for student dashboard
  const [publishedCount, setPublishedCount] = useState<number>(0);
  const [announcementCount, setAnnouncementCount] = useState<number>(0);

  // Initialize device ID for Like & Comment limits (Section 8)
  useEffect(() => {
    let id = localStorage.getItem('smpn1_device_id');
    if (!id) {
      id = 'dev_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
      localStorage.setItem('smpn1_device_id', id);
    }
    setDeviceId(id);
    refreshStats();
    StorageService.syncFromFirestore()
      .then(() => refreshStats())
      .catch(() => {});
  }, []);

  const refreshStats = () => {
    const published = StorageService.getPublishedAspirations();
    const announcements = StorageService.getAnnouncements();
    setPublishedCount(published.length);
    setAnnouncementCount(announcements.length);
  };

  const navigateTo = (view: AppView) => {
    refreshStats();
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#080B20] text-[#D5E9FF] font-sans antialiased selection:bg-[#36CFFF]/30 selection:text-white">
      {currentView === 'landing' && (
        <LandingPage
          onEnterStudentPortal={() => navigateTo('student_dashboard')}
          onEnterAdmin={() => {
            if (isAdminLoggedIn) {
              navigateTo('admin_dashboard');
            } else {
              navigateTo('admin_login');
            }
          }}
          onEnterSafeguarding={() => navigateTo('safeguarding')}
        />
      )}

      {currentView === 'student_dashboard' && (
        <StudentDashboard
          publishedCount={publishedCount}
          announcementCount={announcementCount}
          onNavigate={(target) => {
            if (target === 'submit') navigateTo('submit_aspiration');
            else if (target === 'list') navigateTo('aspiration_list');
            else if (target === 'announcements') navigateTo('school_announcements');
            else if (target === 'landing') navigateTo('landing');
          }}
        />
      )}

      {currentView === 'submit_aspiration' && (
        <SubmitAspirationView
          onBackToDashboard={() => navigateTo('student_dashboard')}
          onSubmittedSuccess={() => {
            refreshStats();
            navigateTo('student_dashboard');
          }}
        />
      )}

      {currentView === 'aspiration_list' && (
        <AspirationListView
          deviceId={deviceId}
          onBackToDashboard={() => navigateTo('student_dashboard')}
        />
      )}

      {currentView === 'school_announcements' && (
        <SchoolAnnouncementsView
          onBackToDashboard={() => navigateTo('student_dashboard')}
        />
      )}

      {currentView === 'admin_login' && (
        <AdminLogin
          onLoginSuccess={() => {
            setIsAdminLoggedIn(true);
            navigateTo('admin_dashboard');
          }}
          onBackToPortal={() => navigateTo('landing')}
        />
      )}

      {currentView === 'admin_dashboard' && (
        <AdminDashboard
          onLogout={() => {
            setIsAdminLoggedIn(false);
            navigateTo('admin_login');
          }}
          onGoToPortal={() => navigateTo('landing')}
        />
      )}

      {currentView === 'safeguarding' && (
        <SafeguardingPortal
          onBackToPortal={() => navigateTo('landing')}
        />
      )}
    </div>
  );
}
