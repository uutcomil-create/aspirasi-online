import {
  Aspiration,
  SensitiveReport,
  Comment,
  Announcement,
  ActivityLog,
  AdminLoginAttempt
} from '../types';
import { db, handleFirestoreError, OperationType } from './firebase';
import { doc, setDoc, deleteDoc, getDocs, collection } from 'firebase/firestore';

const STORAGE_KEYS = {
  ASPIRATIONS: 'smpn1ungaran_aspirations_v1',
  SENSITIVE_REPORTS: 'smpn1ungaran_sensitive_safeguard_v1', // Isolated storage
  COMMENTS: 'smpn1ungaran_comments_v1',
  ANNOUNCEMENTS: 'smpn1ungaran_announcements_v1',
  ACTIVITY_LOGS: 'smpn1ungaran_logs_v1',
  ADMIN_CONFIG: 'smpn1ungaran_admin_config_v1',
  ADMIN_LOGIN_LOGS: 'smpn1ungaran_login_logs_v1',
  DEVICE_LIKES_PREFIX: 'smpn1_liked_',
  DEVICE_COMMENTS_PREFIX: 'smpn1_comments_count_'
};

// Initial Seed Data for SMP Negeri 1 Ungaran
const INITIAL_ASPIRATIONS: Aspiration[] = [
  {
    id: 'asp-1',
    category: 'Sarana dan Prasarana',
    isAnonymous: false,
    authorName: 'Dimas Arya',
    authorClass: '8C',
    title: 'Perbaikan Kipas Angin dan Proyektor di Ruang Lab Komputer 2',
    content: 'Mohon perbaikan pada 2 unit kipas angin dinding di Lab Komputer 2 yang sering mati sendiri saat jam pembelajaran TIK siang hari, serta kabel VGA proyektor yang agak longgar.',
    status: 'Sedang Ditindaklanjuti',
    isPublished: true,
    isPrivate: false,
    createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
    publishedAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    likesCount: 24,
    commentsCount: 3
  },
  {
    id: 'asp-2',
    category: 'Kebersihan dan Lingkungan',
    isAnonymous: true,
    title: 'Penyediaan Tempat Sampah Pilah Khusus Botol Plastik di Kantin',
    content: 'Saat istirahat kedua, tempat sampah di dekat gazebo kantin barat sering penuh dengan botol minuman plastik. Alangkah baiknya jika ditambah tempat sampah pilah khusus botol dan tutupnya agar dapat disalurkan ke Bank Sampah Adiwiyata SMPN 1 Ungaran.',
    status: 'Selesai',
    isPublished: true,
    isPrivate: false,
    createdAt: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
    publishedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
    likesCount: 38,
    commentsCount: 4
  },
  {
    id: 'asp-3',
    category: 'Kegiatan Siswa dan Ekstrakurikuler',
    isAnonymous: false,
    authorName: 'Zaskia Putri',
    authorClass: '9A',
    title: 'Penambahan Kuota Buku Cerita Digital dan Novel di Perpustakaan',
    content: 'Kami mengusulkan agar pojok literasi perpustakaan sekolah menambah koleksi fiksi remaja berbahasa Inggris dan ensiklopedia sains populer terbaru untuk menunjang kegiatan literasi 15 menit sebelum pelajaran.',
    status: 'Sedang Ditinjau',
    isPublished: true,
    isPrivate: false,
    createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    publishedAt: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
    likesCount: 15,
    commentsCount: 2
  },
  {
    id: 'asp-4',
    category: 'Pembelajaran dan Guru',
    isAnonymous: true,
    title: 'Pengaturan Rotasi Jam Latihan Tim Basket dan Futsal di Lapangan Utama',
    content: 'Sering terjadi bentrokan jam latihan ekstrakurikuler basket dan futsal pada hari Rabu sore. Mohon dibuatkan papan jadwal mingguan transparan di dekat ruang OSIS.',
    status: 'Sedang Ditindaklanjuti',
    isPublished: true,
    isPrivate: false,
    createdAt: new Date(Date.now() - 8 * 24 * 3600 * 1000).toISOString(),
    publishedAt: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString(),
    likesCount: 29,
    commentsCount: 1
  },
  {
    id: 'asp-5',
    category: 'Kedisiplinan dan Tata Tertib',
    isAnonymous: false,
    authorName: 'Rian Pratama',
    authorClass: '7F',
    title: 'Penataan Jalur Parkir Sepeda Siswa Dekat Gerbang Timur',
    content: 'Sepeda ontel dan gunung siswa kelas 7 dan 8 sering berdesakan saat jam pulang sekolah. Kami menyarankan pemasangan palang besi penanda nomor sepeda per kelas agar lebih rapi dan aman.',
    status: 'Menunggu Ditinjau',
    isPublished: false,
    isPrivate: false,
    createdAt: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
    likesCount: 0,
    commentsCount: 0
  },
  {
    id: 'asp-6',
    category: 'Sarana dan Prasarana',
    isAnonymous: false,
    authorName: 'Ananda Bagas',
    authorClass: '9E',
    title: 'Pemberian Label dan Cermin Datar di Wastafel Depan Ruang Kesenian',
    content: 'Kran air nomor 3 di wastafel dekat ruang kesenian agak rembes airnya, mohon dicek karet sealnya agar hemat air.',
    status: 'Selesai',
    isPublished: true,
    isPrivate: false,
    createdAt: new Date(Date.now() - 14 * 24 * 3600 * 1000).toISOString(),
    publishedAt: new Date(Date.now() - 13 * 24 * 3600 * 1000).toISOString(),
    likesCount: 12,
    commentsCount: 1
  }
];

const INITIAL_COMMENTS: Comment[] = [
  {
    id: 'com-1',
    aspirationId: 'asp-1',
    nickname: 'Anak_TIK_Ungaran',
    content: 'Setuju banget, kemarin pas ulangan harian layar proyektornya kedip-kedip.',
    createdAt: new Date(Date.now() - 1.5 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'com-2',
    aspirationId: 'asp-1',
    nickname: 'Spensa_Proud',
    content: 'Sudah disampaikan ke Pak Joko bagian sarpras dan teknisi sedang memesan kabel HDMI pengganti.',
    createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'com-3',
    aspirationId: 'asp-2',
    nickname: 'DutaAdiwiyata',
    content: 'Bagus sekali idenya, tim Adiwiyata Spensa Ungaran siap membantu memilah!',
    createdAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString()
  }
];

const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Pelaksanaan Penilaian Tengah Semester (PTS) Genap Tahun Ajaran 2026',
    content: 'Diberitahukan kepada seluruh siswa kelas 7, 8, dan 9 SMP Negeri 1 Ungaran bahwa PTS Genap akan dimulai tanggal 16 November 2026. Seluruh siswa diharapkan mengecek kartu peserta dan hadir 15 menit sebelum bel masuk berbunyi.',
    publisher: 'Wakasek Bidang Kurikulum',
    isImportant: true,
    images: [],
    externalLink: 'https://smpn1ungaran.sch.id',
    publishedAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ann-2',
    title: 'Sosialisasi Pemilihan Ketua OSIS (PILKETOS) Periode 2026/2027',
    content: 'Pendaftaran calon ketua dan wakil ketua OSIS SMP Negeri 1 Ungaran telah dibuka mulai Senin depan. Silakan unduh formulir visi misi dan lengkapi surat rekomendasi dari wali kelas.',
    publisher: 'Pembina OSIS SMPN 1 Ungaran',
    isImportant: true,
    images: [],
    publishedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ann-3',
    title: 'Aksi Jumat Bersih & Perawatan Kebun Toga Lingkungan Sekolah',
    content: 'Kegiatan rutin kebersihan lingkungan sekolah dan perawatan taman kelas masing-masing akan dilaksanakan setiap hari Jumat pagi pukul 06.45 - 07.30 WIB dengan bimbingan wali kelas.',
    publisher: 'Koordinator Sekolah Adiwiyata',
    isImportant: false,
    images: [],
    publishedAt: new Date(Date.now() - 9 * 24 * 3600 * 1000).toISOString()
  }
];

const INITIAL_LOGS: ActivityLog[] = [
  {
    id: 'log-1',
    aspirationId: 'asp-1',
    aspirationTitle: 'Perbaikan Kipas Angin dan Proyektor di Ruang Lab Komputer 2',
    oldStatus: 'Sedang Ditinjau',
    newStatus: 'Sedang Ditindaklanjuti',
    adminActor: 'Admin Utama OSIS',
    timestamp: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    note: 'Diteruskan ke Bagian Sarpras untuk pengecekan kabel dan unit pendingin.'
  },
  {
    id: 'log-2',
    aspirationId: 'asp-2',
    aspirationTitle: 'Penyediaan Tempat Sampah Pilah Khusus Botol Plastik di Kantin',
    oldStatus: 'Sedang Ditindaklanjuti',
    newStatus: 'Selesai',
    adminActor: 'Admin Utama OSIS',
    timestamp: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
    note: 'Telah dipasang 3 unit tong sampah pilah baru dari komite sekolah.'
  }
];

export interface AdminConfig {
  passwordHash: string;
  recoveryCode: string;
  failedAttempts: number;
  lockedUntil: number | null;
}

export const StorageService = {
  getAspirations(): Aspiration[] {
    const data = localStorage.getItem(STORAGE_KEYS.ASPIRATIONS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.ASPIRATIONS, JSON.stringify(INITIAL_ASPIRATIONS));
      return INITIAL_ASPIRATIONS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_ASPIRATIONS;
    }
  },

  // Public student view: ONLY published general aspirations. NEVER sensitive reports.
  getPublishedAspirations(): Aspiration[] {
    const all = this.getAspirations();
    return all.filter((a) => a.isPublished && !a.isPrivate);
  },

  // Admin OSIS view: ALL general aspirations (Public & Private). NEVER sensitive reports!
  getAdminAspirations(): Aspiration[] {
    return this.getAspirations();
  },

  saveAspirations(aspirations: Aspiration[]): void {
    localStorage.setItem(STORAGE_KEYS.ASPIRATIONS, JSON.stringify(aspirations));
  },

  addAspiration(aspirationData: Omit<Aspiration, 'id' | 'createdAt' | 'likesCount' | 'commentsCount' | 'status' | 'isPublished' | 'isPrivate'>): Aspiration {
    const all = this.getAspirations();
    const newAspiration: Aspiration = {
      ...aspirationData,
      id: 'asp-' + Date.now(),
      status: 'Menunggu Ditinjau',
      isPublished: false,
      isPrivate: false,
      createdAt: new Date().toISOString(),
      likesCount: 0,
      commentsCount: 0
    };
    all.unshift(newAspiration);
    this.saveAspirations(all);

    // Sync to Firestore
    setDoc(doc(db, 'aspirations', newAspiration.id), newAspiration).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    return newAspiration;
  },

  updateAspiration(
    id: string,
    updates: Partial<Aspiration>,
    adminActor: string,
    auditNote?: string
  ): Aspiration | null {
    const all = this.getAspirations();
    const index = all.findIndex((a) => a.id === id);
    if (index === -1) return null;

    const old = all[index];
    const statusChanged = updates.status && updates.status !== old.status;

    const updated: Aspiration = {
      ...old,
      ...updates,
      // Preserve original content for audit if edited
      originalTitle: old.originalTitle || (updates.title && updates.title !== old.title ? old.title : undefined),
      originalContent: old.originalContent || (updates.content && updates.content !== old.content ? old.content : undefined)
    };

    all[index] = updated;
    this.saveAspirations(all);

    // Sync to Firestore
    setDoc(doc(db, 'aspirations', id), updated, { merge: true }).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    // If status changed, record audit log
    if (statusChanged && updates.status) {
      this.addActivityLog({
        aspirationId: id,
        aspirationTitle: updated.title,
        oldStatus: old.status,
        newStatus: updates.status,
        adminActor: adminActor,
        note: auditNote
      });
    }

    return updated;
  },

  deleteAspiration(id: string): boolean {
    const all = this.getAspirations();
    const filtered = all.filter((a) => a.id !== id);
    if (filtered.length !== all.length) {
      this.saveAspirations(filtered);

      // Sync delete to Firestore
      deleteDoc(doc(db, 'aspirations', id)).catch((err) => {
        console.warn('Firestore sync note:', err);
      });

      return true;
    }
    return false;
  },

  // ----------------------------------------------------
  // SENSITIVE REPORTS (Jalur Rahasia: Keamanan & Perundungan)
  // Strictly isolated from Admin OSIS queue per Section 3 & 6
  // ----------------------------------------------------
  addSensitiveReport(report: Omit<SensitiveReport, 'id' | 'createdAt' | 'status'>): SensitiveReport {
    const key = STORAGE_KEYS.SENSITIVE_REPORTS;
    let list: SensitiveReport[] = [];
    try {
      const data = localStorage.getItem(key);
      if (data) list = JSON.parse(data);
    } catch {
      list = [];
    }

    const newReport: SensitiveReport = {
      ...report,
      id: 'sec-' + Date.now(),
      createdAt: new Date().toISOString(),
      status: 'Baru Masuk'
    };

    list.unshift(newReport);
    localStorage.setItem(key, JSON.stringify(list));

    // Sync to Firestore sensitiveReports
    setDoc(doc(db, 'sensitiveReports', newReport.id), newReport).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    return newReport;
  },

  getSensitiveReportsForAuthorizedStaff(staffPin: string): SensitiveReport[] {
    // Requires authorized staff PIN ("guru-bk" or "1975bk")
    if (staffPin !== '1975bk' && staffPin !== 'guru-bk' && staffPin !== 'safeguard2026') {
      throw new Error('Akses Ditolak: PIN Petugas Safeguarding Sekolah Tidak Valid.');
    }
    const key = STORAGE_KEYS.SENSITIVE_REPORTS;
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  // ----------------------------------------------------
  // LIKE SYSTEM (1 Like per device per aspiration)
  // ----------------------------------------------------
  hasDeviceLiked(aspirationId: string, deviceId: string): boolean {
    return localStorage.getItem(`${STORAGE_KEYS.DEVICE_LIKES_PREFIX}${deviceId}_${aspirationId}`) === 'true';
  },

  likeAspiration(aspirationId: string, deviceId: string): boolean {
    if (this.hasDeviceLiked(aspirationId, deviceId)) return false;

    const all = this.getAspirations();
    const item = all.find((a) => a.id === aspirationId);
    if (!item) return false;

    item.likesCount = (item.likesCount || 0) + 1;
    this.saveAspirations(all);

    localStorage.setItem(`${STORAGE_KEYS.DEVICE_LIKES_PREFIX}${deviceId}_${aspirationId}`, 'true');
    return true;
  },

  // ----------------------------------------------------
  // COMMENT SYSTEM (Max 3 comments per device per aspiration)
  // ----------------------------------------------------
  getComments(aspirationId?: string): Comment[] {
    const data = localStorage.getItem(STORAGE_KEYS.COMMENTS);
    let list: Comment[] = [];
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.COMMENTS, JSON.stringify(INITIAL_COMMENTS));
      list = INITIAL_COMMENTS;
    } else {
      try {
        list = JSON.parse(data);
      } catch {
        list = INITIAL_COMMENTS;
      }
    }

    if (aspirationId) {
      return list.filter((c) => c.aspirationId === aspirationId);
    }
    return list;
  },

  getDeviceCommentCount(aspirationId: string, deviceId: string): number {
    const val = localStorage.getItem(`${STORAGE_KEYS.DEVICE_COMMENTS_PREFIX}${deviceId}_${aspirationId}`);
    return val ? parseInt(val, 10) : 0;
  },

  addComment(aspirationId: string, nickname: string, content: string, deviceId: string): Comment {
    const currentCount = this.getDeviceCommentCount(aspirationId, deviceId);
    if (currentCount >= 3) {
      throw new Error('Batas maksimal 3 komentar per perangkat untuk aspirasi ini telah tercapai.');
    }

    const comments = this.getComments();
    const newComment: Comment = {
      id: 'com-' + Date.now(),
      aspirationId,
      nickname: nickname.trim(),
      content: content.trim(),
      createdAt: new Date().toISOString()
    };

    comments.unshift(newComment);
    localStorage.setItem(STORAGE_KEYS.COMMENTS, JSON.stringify(comments));
    localStorage.setItem(`${STORAGE_KEYS.DEVICE_COMMENTS_PREFIX}${deviceId}_${aspirationId}`, String(currentCount + 1));

    // Sync comment to Firestore
    setDoc(doc(db, 'comments', newComment.id), newComment).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    // Update aspiration commentsCount
    const all = this.getAspirations();
    const item = all.find((a) => a.id === aspirationId);
    if (item) {
      item.commentsCount = (item.commentsCount || 0) + 1;
      this.saveAspirations(all);
    }

    return newComment;
  },

  deleteComment(commentId: string): boolean {
    const comments = this.getComments();
    const target = comments.find((c) => c.id === commentId);
    if (!target) return false;

    const filtered = comments.filter((c) => c.id !== commentId);
    localStorage.setItem(STORAGE_KEYS.COMMENTS, JSON.stringify(filtered));

    // Sync delete to Firestore
    deleteDoc(doc(db, 'comments', commentId)).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    // decrement count
    const all = this.getAspirations();
    const item = all.find((a) => a.id === target.aspirationId);
    if (item && item.commentsCount > 0) {
      item.commentsCount -= 1;
      this.saveAspirations(all);
    }
    return true;
  },

  // ----------------------------------------------------
  // ANNOUNCEMENTS
  // ----------------------------------------------------
  getAnnouncements(): Announcement[] {
    const data = localStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(INITIAL_ANNOUNCEMENTS));
      return INITIAL_ANNOUNCEMENTS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_ANNOUNCEMENTS;
    }
  },

  saveAnnouncements(list: Announcement[]): void {
    localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(list));
  },

  addAnnouncement(ann: Omit<Announcement, 'id' | 'publishedAt'>): Announcement {
    const list = this.getAnnouncements();
    const newAnn: Announcement = {
      ...ann,
      id: 'ann-' + Date.now(),
      publishedAt: new Date().toISOString()
    };
    list.unshift(newAnn);
    this.saveAnnouncements(list);

    // Sync to Firestore announcements
    setDoc(doc(db, 'announcements', newAnn.id), newAnn).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    return newAnn;
  },

  updateAnnouncement(id: string, updates: Partial<Announcement>): Announcement | null {
    const list = this.getAnnouncements();
    const idx = list.findIndex((a) => a.id === id);
    if (idx === -1) return null;

    list[idx] = { ...list[idx], ...updates };
    this.saveAnnouncements(list);

    // Sync update to Firestore
    setDoc(doc(db, 'announcements', id), list[idx], { merge: true }).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    return list[idx];
  },

  deleteAnnouncement(id: string): boolean {
    const list = this.getAnnouncements();
    const filtered = list.filter((a) => a.id !== id);
    if (filtered.length !== list.length) {
      this.saveAnnouncements(filtered);

      // Sync delete to Firestore
      deleteDoc(doc(db, 'announcements', id)).catch((err) => {
        console.warn('Firestore sync note:', err);
      });

      return true;
    }
    return false;
  },

  // ----------------------------------------------------
  // ACTIVITY AUDIT LOGS
  // ----------------------------------------------------
  getActivityLogs(): ActivityLog[] {
    const data = localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOGS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(INITIAL_LOGS));
      return INITIAL_LOGS;
    }
    try {
      return JSON.parse(data);
    } catch {
      return INITIAL_LOGS;
    }
  },

  addActivityLog(logData: Omit<ActivityLog, 'id' | 'timestamp'>): ActivityLog {
    const list = this.getActivityLogs();
    const newLog: ActivityLog = {
      ...logData,
      id: 'log-' + Date.now(),
      timestamp: new Date().toISOString()
    };
    list.unshift(newLog);
    localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(list));

    // Sync to Firestore activityLogs
    setDoc(doc(db, 'activityLogs', newLog.id), newLog).catch((err) => {
      console.warn('Firestore sync note:', err);
    });

    return newLog;
  },

  // ----------------------------------------------------
  // ADMIN AUTHENTICATION & SECURITY
  // ----------------------------------------------------
  getAdminConfig(): {
    passwordHash: string;
    recoveryCode: string;
    failedAttempts: number;
    lockedUntil: number | null;
  } {
    const saved = localStorage.getItem(STORAGE_KEYS.ADMIN_CONFIG);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    const defaultConfig = {
      passwordHash: 'admin123', // default plain/hash representation
      recoveryCode: 'UNGARAN-RECOVER-2026',
      failedAttempts: 0,
      lockedUntil: null
    };
    localStorage.setItem(STORAGE_KEYS.ADMIN_CONFIG, JSON.stringify(defaultConfig));
    return defaultConfig;
  },

  saveAdminConfig(config: AdminConfig): void {
    localStorage.setItem(STORAGE_KEYS.ADMIN_CONFIG, JSON.stringify(config));
  },

  recordLoginAttempt(success: boolean): void {
    const logs: AdminLoginAttempt[] = [];
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ADMIN_LOGIN_LOGS);
      if (data) logs.push(...JSON.parse(data));
    } catch {
      // ignore
    }
    logs.unshift({
      timestamp: new Date().toISOString(),
      success,
      ipPlaceholder: '192.168.1.' + Math.floor(Math.random() * 200 + 10)
    });
    localStorage.setItem(STORAGE_KEYS.ADMIN_LOGIN_LOGS, JSON.stringify(logs.slice(0, 30)));
  },

  getLoginLogs(): AdminLoginAttempt[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ADMIN_LOGIN_LOGS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  async syncFromFirestore(): Promise<void> {
    try {
      const snap = await getDocs(collection(db, 'aspirations'));
      if (!snap.empty) {
        const remoteAspirations: Aspiration[] = [];
        snap.forEach((d) => remoteAspirations.push(d.data() as Aspiration));
        if (remoteAspirations.length > 0) {
          localStorage.setItem(STORAGE_KEYS.ASPIRATIONS, JSON.stringify(remoteAspirations));
        }
      }
    } catch (e) {
      console.warn('Firestore background sync using offline cache.');
    }
  }
};
