import { getAccessToken } from './googleDriveAuth';

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  webContentLink?: string;
  thumbnailLink?: string;
  iconLink?: string;
  createdTime?: string;
  size?: string;
}

export interface DriveAboutInfo {
  user: {
    displayName: string;
    emailAddress: string;
    photoLink?: string;
  };
  storageQuota?: {
    limit?: string;
    usage?: string;
    usageInDrive?: string;
  };
}

export const GoogleDriveService = {
  async getAboutInfo(): Promise<DriveAboutInfo> {
    const token = await getAccessToken();
    if (!token) throw new Error('Akses Google Drive belum diotentikasi. Silakan masuk dengan Google.');

    const res = await fetch('https://www.googleapis.com/drive/v3/about?fields=user,storageQuota', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || `Gagal mengambil profil Google Drive (${res.status})`);
    }

    return await res.json();
  },

  async listFiles(querySearch?: string, folderId?: string): Promise<DriveFileItem[]> {
    const token = await getAccessToken();
    if (!token) throw new Error('Akses Google Drive belum diotentikasi.');

    let q = "trashed = false";
    if (folderId) {
      q += ` and '${folderId}' in parents`;
    }
    if (querySearch?.trim()) {
      const sanitized = querySearch.trim().replace(/'/g, "\\'");
      q += ` and name contains '${sanitized}'`;
    }

    const params = new URLSearchParams({
      q,
      fields: 'files(id, name, mimeType, webViewLink, webContentLink, iconLink, thumbnailLink, createdTime, size)',
      orderBy: 'folder,modifiedTime desc',
      pageSize: '30'
    });

    const res = await fetch(`https://www.googleapis.com/drive/v3/files?${params.toString()}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || `Gagal memuat berkas dari Google Drive (${res.status})`);
    }

    const data = await res.json();
    return data.files || [];
  },

  async uploadFile(file: File, folderId?: string): Promise<DriveFileItem> {
    const token = await getAccessToken();
    if (!token) throw new Error('Akses Google Drive belum diotentikasi.');

    const metadata: { name: string; mimeType: string; parents?: string[] } = {
      name: file.name,
      mimeType: file.type || 'application/octet-stream'
    };

    if (folderId) {
      metadata.parents = [folderId];
    }

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const fileReader = new FileReader();

    return new Promise<DriveFileItem>((resolve, reject) => {
      fileReader.onload = async () => {
        try {
          const arrayBuffer = fileReader.result as ArrayBuffer;
          const bytes = new Uint8Array(arrayBuffer);

          const metadataPart = `${delimiter}Content-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n`;
          const mediaHeaderPart = `${delimiter}Content-Type: ${file.type || 'application/octet-stream'}\r\nContent-Transfer-Encoding: base64\r\n\r\n`;

          // Convert bytes to base64
          let binary = '';
          const len = bytes.byteLength;
          for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
          }
          const base64Data = btoa(binary);

          const multipartBody = `${metadataPart}${mediaHeaderPart}${base64Data}${closeDelimiter}`;

          const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,webContentLink,thumbnailLink', {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${token}`,
              'Content-Type': `multipart/related; boundary=${boundary}`
            },
            body: multipartBody
          });

          if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error?.message || `Gagal mengunggah file (${res.status})`);
          }

          const uploaded = await res.json();
          resolve(uploaded);
        } catch (error) {
          reject(error);
        }
      };

      fileReader.onerror = () => {
        reject(new Error('Gagal membaca file dari sistem lokal.'));
      };

      fileReader.readAsArrayBuffer(file);
    });
  },

  async createFolder(folderName: string, parentFolderId?: string): Promise<DriveFileItem> {
    const token = await getAccessToken();
    if (!token) throw new Error('Akses Google Drive belum diotentikasi.');

    const metadata: { name: string; mimeType: string; parents?: string[] } = {
      name: folderName.trim(),
      mimeType: 'application/vnd.google-apps.folder'
    };

    if (parentFolderId) {
      metadata.parents = [parentFolderId];
    }

    const res = await fetch('https://www.googleapis.com/drive/v3/files?fields=id,name,mimeType,webViewLink', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(metadata)
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Gagal membuat folder baru di Google Drive.');
    }

    return await res.json();
  },

  async deleteFile(fileId: string): Promise<void> {
    const token = await getAccessToken();
    if (!token) throw new Error('Akses Google Drive belum diotentikasi.');

    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!res.ok && res.status !== 204) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Gagal menghapus file dari Google Drive.');
    }
  }
};
