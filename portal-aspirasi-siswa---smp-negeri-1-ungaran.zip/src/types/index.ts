export type AspirationCategory =
  | 'Sarana dan Prasarana'
  | 'Pembelajaran dan Guru'
  | 'Kebersihan dan Lingkungan'
  | 'Kegiatan Siswa dan Ekstrakurikuler'
  | 'Kedisiplinan dan Tata Tertib'
  | 'Keamanan dan Perundungan'
  | 'Lainnya';

export type AspirationStatus =
  | 'Menunggu Ditinjau'
  | 'Sedang Ditinjau'
  | 'Sedang Ditindaklanjuti'
  | 'Selesai';

export interface Aspiration {
  id: string;
  category: AspirationCategory;
  isAnonymous: boolean;
  authorName?: string;
  authorClass?: string;
  title: string;
  content: string;
  originalTitle?: string;
  originalContent?: string;
  attachmentUrl?: string;
  status: AspirationStatus;
  isPublished: boolean;
  isPrivate: boolean;
  createdAt: string; // ISO String
  publishedAt?: string;
  likesCount: number;
  commentsCount: number;
}

export interface Comment {
  id: string;
  aspirationId: string;
  nickname: string;
  content: string;
  createdAt: string;
}

export interface SensitiveReport {
  id: string;
  isAnonymous: boolean;
  reporterName?: string;
  reporterClass?: string;
  title: string;
  content: string;
  attachmentUrls: string[];
  createdAt: string;
  status: 'Baru Masuk' | 'Dalam Penanganan BK' | 'Selesai';
  handledBy?: string;
  officerNotes?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  publisher: string;
  isImportant: boolean;
  images: string[];
  externalLink?: string;
  publishedAt: string;
}

export interface ActivityLog {
  id: string;
  aspirationId: string;
  aspirationTitle: string;
  oldStatus: AspirationStatus;
  newStatus: AspirationStatus;
  adminActor: string;
  timestamp: string;
  note?: string;
}

export interface AdminLoginAttempt {
  timestamp: string;
  success: boolean;
  ipPlaceholder: string;
}

export const STUDENT_CLASSES = [
  '7A', '7B', '7C', '7D', '7E', '7F', '7G', '7H', '7I',
  '8A', '8B', '8C', '8D', '8E', '8F', '8G', '8H', '8I',
  '9A', '9B', '9C', '9D', '9E', '9F', '9G', '9H', '9I'
] as const;

export const CATEGORIES: AspirationCategory[] = [
  'Sarana dan Prasarana',
  'Pembelajaran dan Guru',
  'Kebersihan dan Lingkungan',
  'Kegiatan Siswa dan Ekstrakurikuler',
  'Kedisiplinan dan Tata Tertib',
  'Keamanan dan Perundungan',
  'Lainnya'
];
